import ast
import json
import re
from collections.abc import Mapping, Sequence
from typing import Literal, TypedDict

from core.bug_detector import BugFinding
from static_analysis.analyzer import AnalysisResult

FindingSource = Literal["Confirmed static", "AI suggestion"]


class ConfirmedFinding(TypedDict):
    filename: str
    line: int
    severity: str
    category: str
    issue: str
    explanation: str
    source: Literal["Confirmed static"]


class AISuggestion(TypedDict):
    line: int
    severity: str
    category: str
    issue: str
    explanation: str
    recommendation: str
    source: Literal["AI suggestion"]


class FileReview(TypedDict):
    filename: str
    static_analysis: list[AnalysisResult]
    bug_detection: list[BugFinding]
    confirmed_findings: list[ConfirmedFinding]
    ai_suggestions: list[AISuggestion]
    ai_summary: str | None
    ai_review: str | None
    ai_review_status: str
    ai_review_error: str | None


AI_CATEGORIES = {
    "Bug",
    "Security",
    "Code Quality",
    "Performance",
    "Maintainability",
    "Type Safety",
    "Other",
}
AI_SEVERITIES = {"Critical", "High", "Medium", "Low", "Info"}
_MYPY_LINE = re.compile(
    r"(?m)^[^\r\n]*?:(\d+):\s*error:\s*(.*?)(?:\s+\[([^\]\r\n]+)\])?$"
)
_UNUSED_CLAIM = re.compile(
    r"\b(unused|never\s+used|not\s+used|unreferenced)\b",
    re.IGNORECASE,
)
_AI_SUGGESTION_FIELDS = {
    "line",
    "severity",
    "category",
    "issue",
    "explanation",
    "recommendation",
    "evidence",
}


def _reject_json_constant(value: str) -> None:
    raise ValueError(f"Invalid JSON constant: {value}")


def _severity(value: object) -> str | None:
    if not isinstance(value, str):
        return None
    normalized = value.strip().title()
    return normalized if normalized in AI_SEVERITIES else None


def _append_finding(
    findings: list[ConfirmedFinding],
    seen: set[tuple[int, str, str]],
    filename: str,
    line: int,
    severity: str,
    category: str,
    issue: str,
    explanation: str,
) -> None:
    if line < 1:
        return
    key = (line, category, issue)
    if key in seen:
        return
    seen.add(key)
    findings.append(
        {
            "filename": filename,
            "line": line,
            "severity": severity,
            "category": category,
            "issue": issue,
            "explanation": explanation,
            "source": "Confirmed static",
        }
    )


def collect_confirmed_findings(
    filename: str,
    static_analysis: Sequence[AnalysisResult],
    bug_detection: Sequence[BugFinding],
) -> list[ConfirmedFinding]:
    """Normalize AST, Ruff, Bandit, and Mypy results into line-based findings."""
    findings: list[ConfirmedFinding] = []
    seen: set[tuple[int, str, str]] = set()
    if not isinstance(filename, str):
        return findings

    if not isinstance(bug_detection, Sequence) or isinstance(
        bug_detection,
        (str, bytes),
    ):
        bug_detection = ()
    if not isinstance(static_analysis, Sequence) or isinstance(
        static_analysis,
        (str, bytes),
    ):
        static_analysis = ()

    for finding in bug_detection:
        if not isinstance(finding, Mapping):
            continue
        line = finding.get("line")
        severity = finding.get("severity")
        issue = finding.get("issue")
        explanation = finding.get("explanation")
        if (
            type(line) is not int
            or not isinstance(severity, str)
            or severity not in {"High", "Medium", "Low"}
            or not isinstance(issue, str)
            or not issue.strip()
            or not isinstance(explanation, str)
            or not explanation.strip()
        ):
            continue
        category = "Syntax" if issue == "Syntax error" else "Bug Detection"
        _append_finding(
            findings,
            seen,
            filename,
            line,
            severity,
            category,
            issue,
            explanation,
        )

    for result in static_analysis:
        if not isinstance(result, Mapping):
            continue
        tool_value = result.get("tool")
        message = result.get("message")
        if (
            result.get("status") != "Issues Found"
            or not isinstance(tool_value, str)
            or not isinstance(message, str)
        ):
            continue
        tool = tool_value.strip().lower()

        if tool == "ruff":
            try:
                report = json.loads(message)
            except (json.JSONDecodeError, TypeError, RecursionError):
                continue
            if not isinstance(report, list):
                continue
            for item in report:
                if not isinstance(item, Mapping):
                    continue
                location = item.get("location")
                if not isinstance(location, Mapping):
                    continue
                ruff_line = location.get("row")
                code = item.get("code")
                description = item.get("message")
                if (
                    type(ruff_line) is not int
                    or not isinstance(code, str)
                    or not code.strip()
                    or not isinstance(description, str)
                    or not description.strip()
                ):
                    continue
                _append_finding(
                    findings,
                    seen,
                    filename,
                    ruff_line,
                    "Medium",
                    "Code Quality",
                    f"Ruff {code}: {description}",
                    description,
                )

        elif tool == "bandit":
            try:
                report = json.loads(message)
            except (json.JSONDecodeError, TypeError, RecursionError):
                continue
            if not isinstance(report, dict):
                continue
            results = report.get("results")
            if not isinstance(results, list):
                continue
            for item in results:
                if not isinstance(item, Mapping):
                    continue
                bandit_line = item.get("line_number")
                issue_text = item.get("issue_text")
                test_id = item.get("test_id")
                bandit_severity = _severity(item.get("issue_severity"))
                if (
                    type(bandit_line) is not int
                    or not isinstance(issue_text, str)
                    or not issue_text.strip()
                    or not isinstance(test_id, str)
                    or not test_id.strip()
                    or bandit_severity is None
                ):
                    continue
                _append_finding(
                    findings,
                    seen,
                    filename,
                    bandit_line,
                    bandit_severity,
                    "Security",
                    f"Bandit {test_id}: {issue_text}",
                    issue_text,
                )

        elif tool == "mypy":
            for match in _MYPY_LINE.finditer(message):
                try:
                    mypy_line = int(match.group(1))
                except ValueError:
                    continue
                description = match.group(2).strip()
                if not description:
                    continue
                code = match.group(3)
                issue = (
                    f"Mypy {code}: {description}"
                    if code
                    else f"Mypy: {description}"
                )
                _append_finding(
                    findings,
                    seen,
                    filename,
                    mypy_line,
                    "Medium",
                    "Type Checking",
                    issue,
                    description,
                )

    findings.sort(key=lambda item: (item["line"], item["category"], item["issue"]))
    return findings


def _has_later_reference(code: str, line: int, names: set[str]) -> bool:
    if not names:
        return True
    try:
        tree = ast.parse(code)
    except (SyntaxError, ValueError, RecursionError):
        return True
    assignments: dict[str, list[int]] = {}
    for node in ast.walk(tree):
        if (
            isinstance(node, ast.Name)
            and isinstance(node.ctx, ast.Store)
            and node.id in names
            and node.lineno == line
        ):
            assignments.setdefault(node.id, []).append(node.col_offset)
    return any(
        isinstance(node, ast.Name)
        and isinstance(node.ctx, ast.Load)
        and node.id in assignments
        and any(
            (node.lineno, node.col_offset) > (line, assignment_column)
            for assignment_column in assignments[node.id]
        )
        for node in ast.walk(tree)
    )


def _unused_claim_is_supported(
    code: str,
    line: int,
    issue: str,
) -> bool:
    try:
        tree = ast.parse(code)
    except (SyntaxError, ValueError, RecursionError):
        return False

    assigned_names = {
        node.id
        for node in ast.walk(tree)
        if isinstance(node, ast.Name)
        and isinstance(node.ctx, ast.Store)
        and node.lineno == line
    }
    claimed_names = {
        name
        for name in assigned_names
        if re.search(rf"\b{re.escape(name)}\b", issue)
    }
    return bool(claimed_names) and not _has_later_reference(
        code,
        line,
        claimed_names,
    )


def validate_ai_response(
    response: str,
    code: str,
    confirmed_findings: Sequence[ConfirmedFinding],
) -> tuple[str | None, list[AISuggestion]]:
    """Parse and validate AI claims against exact source lines and static results."""
    if not isinstance(response, str) or not isinstance(code, str):
        return None, []
    try:
        payload = json.loads(
            response,
            parse_constant=_reject_json_constant,
        )
    except (json.JSONDecodeError, TypeError, ValueError, RecursionError):
        return None, []
    if not isinstance(payload, dict):
        return None, []

    summary = payload.get("executive_summary")
    candidates = payload.get("suggestions")
    if (
        not isinstance(summary, str)
        or not summary.strip()
        or len(summary) > 1000
        or not isinstance(candidates, list)
    ):
        return None, []
    if _UNUSED_CLAIM.search(summary):
        return None, []

    source_lines = code.splitlines()
    if not isinstance(confirmed_findings, Sequence) or isinstance(
        confirmed_findings,
        (str, bytes),
    ):
        confirmed_findings = ()
    confirmed_lines = {
        finding.get("line")
        for finding in confirmed_findings
        if isinstance(finding, Mapping) and type(finding.get("line")) is int
    }
    suggestions: list[AISuggestion] = []
    seen: set[tuple[int, str, str]] = set()

    for item in candidates[:50]:
        if not isinstance(item, dict) or set(item) != _AI_SUGGESTION_FIELDS:
            continue
        line = item.get("line")
        category = item.get("category")
        severity = item.get("severity")
        issue = item.get("issue")
        explanation = item.get("explanation")
        recommendation = item.get("recommendation")
        evidence = item.get("evidence")

        if (
            type(line) is not int
            or line < 1
            or line > len(source_lines)
            or line in confirmed_lines
            or not isinstance(category, str)
            or category not in AI_CATEGORIES
            or not isinstance(severity, str)
            or severity not in AI_SEVERITIES
            or not isinstance(issue, str)
            or not issue.strip()
            or not isinstance(explanation, str)
            or not explanation.strip()
            or not isinstance(recommendation, str)
            or not recommendation.strip()
            or not isinstance(evidence, str)
            or not evidence.strip()
        ):
            continue
        if (
            len(issue) > 300
            or len(explanation) > 1000
            or len(recommendation) > 1000
            or len(evidence) > 500
            or evidence not in source_lines[line - 1]
        ):
            continue
        if _UNUSED_CLAIM.search(f"{issue} {explanation} {recommendation}") and (
            not _unused_claim_is_supported(code, line, issue)
        ):
            continue

        key = (line, category, issue.strip().casefold())
        if key in seen:
            continue
        seen.add(key)
        suggestions.append(
            {
                "line": line,
                "severity": severity,
                "category": category,
                "issue": issue.strip(),
                "explanation": explanation.strip(),
                "recommendation": recommendation.strip(),
                "source": "AI suggestion",
            }
        )

    return summary.strip(), suggestions
