import ast
from typing import Literal, TypedDict


class BugFinding(TypedDict):
    line: int
    severity: Literal["High", "Medium", "Low"]
    issue: str
    explanation: str


def _finding(
    line: int,
    severity: Literal["High", "Medium", "Low"],
    issue: str,
    explanation: str,
) -> BugFinding:
    return {
        "line": line,
        "severity": severity,
        "issue": issue,
        "explanation": explanation,
    }


def _is_zero_literal(node: ast.expr) -> bool:
    if isinstance(node, ast.Constant):
        return type(node.value) in (int, float, complex) and node.value == 0

    if (
        isinstance(node, ast.UnaryOp)
        and isinstance(node.op, (ast.UAdd, ast.USub))
        and isinstance(node.operand, ast.Constant)
    ):
        value = node.operand.value
        return type(value) in (int, float, complex) and value == 0

    return False


def _broad_exception_kind(node: ast.expr) -> str | None:
    if isinstance(node, ast.Name) and node.id in {"Exception", "BaseException"}:
        return node.id

    if isinstance(node, ast.Attribute) and node.attr in {
        "Exception",
        "BaseException",
    }:
        return node.attr

    if isinstance(node, ast.Tuple):
        kinds = [
            kind
            for item in node.elts
            if (kind := _broad_exception_kind(item)) is not None
        ]
        if "BaseException" in kinds:
            return "BaseException"
        if kinds:
            return "Exception"

    return None


def _is_suspicious_assertion(test: ast.expr) -> bool:
    try:
        value = ast.literal_eval(test)
    except (ValueError, TypeError, SyntaxError, MemoryError, RecursionError):
        return False

    return not bool(value)


def detect_bugs(code: object) -> list[BugFinding]:
    """Find selected Python bug patterns without executing the source."""
    if not isinstance(code, str) or not code.strip():
        return [
            _finding(
                1,
                "Low",
                "Invalid input",
                "Provide non-empty Python source code as text.",
            )
        ]

    try:
        tree = ast.parse(code)
    except SyntaxError as error:
        return [
            _finding(
                error.lineno or 1,
                "High",
                "Syntax error",
                error.msg,
            )
        ]
    except (ValueError, RecursionError):
        return [
            _finding(
                1,
                "High",
                "Syntax error",
                "The source could not be parsed as valid Python.",
            )
        ]

    findings: list[BugFinding] = []

    for node in ast.walk(tree):
        if (
            isinstance(node, ast.BinOp)
            and isinstance(node.op, (ast.Div, ast.FloorDiv, ast.Mod))
            and _is_zero_literal(node.right)
        ):
            findings.append(
                _finding(
                    node.lineno,
                    "High",
                    "Division by zero",
                    "The divisor is a literal zero, which raises ZeroDivisionError.",
                )
            )

        elif isinstance(node, ast.ExceptHandler):
            if node.type is None:
                findings.append(
                    _finding(
                        node.lineno,
                        "High",
                        "Bare except clause",
                        "A bare except catches nearly every exception, including "
                        "interrupts; catch the specific exceptions expected here.",
                    )
                )
            else:
                kind = _broad_exception_kind(node.type)
                if kind is not None:
                    severity: Literal["High", "Medium"] = (
                        "High" if kind == "BaseException" else "Medium"
                    )
                    findings.append(
                        _finding(
                            node.lineno,
                            severity,
                            "Broad exception handling",
                            f"Catching {kind} can hide unrelated failures; catch "
                            "the specific exceptions expected here.",
                        )
                    )

        elif isinstance(node, ast.Assert) and _is_suspicious_assertion(node.test):
            findings.append(
                _finding(
                    node.lineno,
                    "Medium",
                    "Suspicious assertion",
                    "This assertion is statically false and will raise "
                    "AssertionError whenever it is reached.",
                )
            )

    findings.sort(key=lambda finding: finding["line"])
    return findings
