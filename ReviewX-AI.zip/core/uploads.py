import io
import stat
import zipfile
import zlib
from pathlib import PurePosixPath, PureWindowsPath

from static_analysis.analyzer import MAX_CODE_SIZE_BYTES

MAX_ARCHIVE_BYTES = 10 * 1024 * 1024
MAX_ARCHIVE_UNCOMPRESSED_BYTES = 50 * 1024 * 1024
MAX_ARCHIVE_ENTRIES = 500
MAX_ARCHIVE_PYTHON_FILES = 25


class UploadValidationError(ValueError):
    """Raised when an uploaded source or archive violates upload limits."""


def read_python_upload(filename: str, content: bytes) -> str:
    """Validate and decode an individual UTF-8 Python upload."""
    if PureWindowsPath(filename).suffix.lower() != ".py":
        raise UploadValidationError("Upload a file with a .py extension.")
    if not content:
        raise UploadValidationError("The uploaded Python file is empty.")
    if len(content) > MAX_CODE_SIZE_BYTES:
        raise UploadValidationError(
            f"The Python file exceeds the {MAX_CODE_SIZE_BYTES}-byte limit."
        )

    try:
        return content.decode("utf-8-sig")
    except UnicodeDecodeError:
        raise UploadValidationError(
            "The Python file must use UTF-8 text encoding."
        ) from None


def _validate_archive_name(filename: str) -> str:
    if not filename or "\x00" in filename:
        raise UploadValidationError("The ZIP archive contains an invalid path.")

    posix_path = PurePosixPath(filename.replace("\\", "/"))
    windows_path = PureWindowsPath(filename)
    if (
        posix_path.is_absolute()
        or windows_path.is_absolute()
        or windows_path.drive
        or ".." in posix_path.parts
        or ".." in windows_path.parts
    ):
        raise UploadValidationError(
            "The ZIP archive contains an unsafe path."
        )

    normalized = posix_path.as_posix()
    if normalized in {"", "."}:
        raise UploadValidationError("The ZIP archive contains an invalid path.")
    return normalized


def extract_python_files(archive_bytes: bytes) -> dict[str, str]:
    """Read eligible Python files from a bounded ZIP entirely in memory."""
    if not archive_bytes:
        raise UploadValidationError("The ZIP archive is empty.")
    if len(archive_bytes) > MAX_ARCHIVE_BYTES:
        raise UploadValidationError(
            f"The ZIP archive exceeds the {MAX_ARCHIVE_BYTES}-byte limit."
        )

    try:
        archive = zipfile.ZipFile(io.BytesIO(archive_bytes))
    except (zipfile.BadZipFile, OSError, ValueError):
        raise UploadValidationError("The uploaded file is not a valid ZIP archive.") from None

    extracted: dict[str, str] = {}
    seen_paths: set[str] = set()
    try:
        entries = archive.infolist()
        if len(entries) > MAX_ARCHIVE_ENTRIES:
            raise UploadValidationError(
                f"The ZIP archive contains more than {MAX_ARCHIVE_ENTRIES} entries."
            )

        total_size = 0
        for info in entries:
            normalized = _validate_archive_name(info.filename)
            path_key = normalized.casefold()
            if path_key in seen_paths:
                raise UploadValidationError(
                    "The ZIP archive contains duplicate paths."
                )
            seen_paths.add(path_key)

            mode = info.external_attr >> 16
            if stat.S_ISLNK(mode):
                raise UploadValidationError(
                    "The ZIP archive contains a symbolic link."
                )
            if info.flag_bits & 0x1:
                raise UploadValidationError(
                    "Encrypted ZIP entries are not supported."
                )
            if info.file_size < 0:
                raise UploadValidationError(
                    "The ZIP archive contains invalid size metadata."
                )

            total_size += info.file_size
            if total_size > MAX_ARCHIVE_UNCOMPRESSED_BYTES:
                raise UploadValidationError(
                    "The ZIP archive exceeds the uncompressed size limit."
                )

        for info in entries:
            if info.is_dir():
                continue

            normalized = _validate_archive_name(info.filename)
            if PurePosixPath(normalized).suffix.lower() != ".py":
                continue
            if info.file_size > MAX_CODE_SIZE_BYTES:
                raise UploadValidationError(
                    f"{normalized} exceeds the {MAX_CODE_SIZE_BYTES}-byte limit."
                )
            if len(extracted) >= MAX_ARCHIVE_PYTHON_FILES:
                raise UploadValidationError(
                    "The ZIP archive contains more than "
                    f"{MAX_ARCHIVE_PYTHON_FILES} Python files."
                )

            try:
                with archive.open(info, "r") as source_file:
                    content = source_file.read(MAX_CODE_SIZE_BYTES + 1)
            except (
                zipfile.BadZipFile,
                OSError,
                EOFError,
                RuntimeError,
                NotImplementedError,
                zlib.error,
            ):
                raise UploadValidationError(
                    "A ZIP entry could not be safely read."
                ) from None

            if len(content) != info.file_size or len(content) > MAX_CODE_SIZE_BYTES:
                raise UploadValidationError(
                    f"{normalized} has inconsistent or oversized content."
                )
            try:
                source = content.decode("utf-8-sig")
            except UnicodeDecodeError:
                raise UploadValidationError(
                    f"{normalized} must use UTF-8 text encoding."
                ) from None
            extracted[normalized] = source
    finally:
        archive.close()

    if not extracted:
        raise UploadValidationError(
            "The ZIP archive contains no eligible Python files."
        )
    return dict(sorted(extracted.items()))
