import json
import unittest

from core.findings import collect_confirmed_findings, validate_ai_response


class TestFindings(unittest.TestCase):
    def test_tool_results_are_grouped_as_confirmed_findings(self):
        static_results = [
            {
                "tool": "ruff",
                "status": "Issues Found",
                "message": json.dumps(
                    [
                        {
                            "code": "F821",
                            "message": "Undefined name",
                            "location": {"row": 2, "column": 4},
                        }
                    ]
                ),
                "exit_code": 1,
            },
            {
                "tool": "bandit",
                "status": "Issues Found",
                "message": json.dumps(
                    {
                        "results": [
                            {
                                "issue_severity": "HIGH",
                                "issue_text": "Unsafe operation",
                                "test_id": "B999",
                                "line_number": 3,
                            }
                        ]
                    }
                ),
                "exit_code": 1,
            },
            {
                "tool": "mypy",
                "status": "Issues Found",
                "message": r"C:\tmp\submitted.py:4: error: Bad type [arg-type]",
                "exit_code": 1,
            },
        ]
        bug_results = [
            {
                "line": 1,
                "severity": "High",
                "issue": "Division by zero",
                "explanation": "Literal zero divisor.",
            }
        ]

        findings = collect_confirmed_findings(
            "pkg/module.py",
            static_results,
            bug_results,
        )

        self.assertEqual(
            [(item["line"], item["category"]) for item in findings],
            [
                (1, "Bug Detection"),
                (2, "Code Quality"),
                (3, "Security"),
                (4, "Type Checking"),
            ],
        )
        self.assertTrue(all(item["source"] == "Confirmed static" for item in findings))
        self.assertEqual(findings[2]["severity"], "High")
        self.assertEqual(findings[0]["filename"], "pkg/module.py")

    def test_ai_suggestions_require_exact_evidence_and_unconfirmed_lines(self):
        source = "first = 1\nsecond = 2\nthird = 3\n"
        confirmed = [
            {
                "filename": "module.py",
                "line": 1,
                "severity": "High",
                "category": "Bug Detection",
                "issue": "Confirmed issue",
                "explanation": "Static result.",
                "source": "Confirmed static",
            }
        ]
        response = {
            "executive_summary": "One optional improvement.",
            "suggestions": [
                {
                    "line": 1,
                    "severity": "Low",
                    "category": "Code Quality",
                    "issue": "Conflicts with confirmed result",
                    "explanation": "This duplicates a static finding.",
                    "evidence": "first = 1",
                    "recommendation": "Change it.",
                },
                {
                    "line": 2,
                    "severity": "Low",
                    "category": "Code Quality",
                    "issue": "Possible simplification",
                    "explanation": "This line could be clearer.",
                    "evidence": "second = 2",
                    "recommendation": "Use a named constant.",
                },
                {
                    "line": 3,
                    "severity": "Low",
                    "category": "Code Quality",
                    "issue": "Unsupported claim",
                    "explanation": "The evidence is not on this line.",
                    "evidence": "not present",
                    "recommendation": "Change it.",
                },
                {
                    "line": 99,
                    "severity": "Low",
                    "category": "Code Quality",
                    "issue": "Invalid location",
                    "explanation": "Out of range.",
                    "evidence": "third = 3",
                    "recommendation": "Change it.",
                },
            ],
        }

        summary, suggestions = validate_ai_response(
            json.dumps(response),
            source,
            confirmed,
        )

        self.assertEqual(summary, "One optional improvement.")
        self.assertEqual(len(suggestions), 1)
        self.assertEqual(suggestions[0]["line"], 2)
        self.assertEqual(suggestions[0]["source"], "AI suggestion")

    def test_ai_unused_claim_is_rejected_if_assigned_name_is_later_referenced(self):
        response = {
            "executive_summary": "Review complete.",
            "suggestions": [
                {
                    "line": 1,
                    "severity": "Low",
                    "category": "Code Quality",
                    "issue": "Unused variable value",
                    "explanation": "The variable is unused.",
                    "evidence": "value = 1",
                    "recommendation": "Remove value.",
                }
            ],
        }
        source = "value = 1\nprint(value)\n"

        _, suggestions = validate_ai_response(json.dumps(response), source, [])

        self.assertEqual(suggestions, [])

    def test_ai_unused_claim_is_rejected_for_later_reference_on_same_line(self):
        response = {
            "executive_summary": "Review complete.",
            "suggestions": [
                {
                    "line": 1,
                    "severity": "Low",
                    "category": "Code Quality",
                    "issue": "Unused variable value",
                    "explanation": "The variable is unused.",
                    "evidence": "value = 1",
                    "recommendation": "Remove value.",
                }
            ],
        }

        _, suggestions = validate_ai_response(
            json.dumps(response),
            "value = 1; print(value)",
            [],
        )

        self.assertEqual(suggestions, [])

    def test_ai_unused_claim_requires_a_supported_assignment_and_name(self):
        response = {
            "executive_summary": "Review complete.",
            "suggestions": [
                {
                    "line": 1,
                    "severity": "Low",
                    "category": "Code Quality",
                    "issue": "Unused variable unused_value",
                    "explanation": "No later reference was found.",
                    "evidence": "unused_value = 1",
                    "recommendation": "Remove unused_value.",
                }
            ],
        }

        _, suggestions = validate_ai_response(
            json.dumps(response),
            "unused_value = 1\nprint('done')\n",
            [],
        )
        self.assertEqual(len(suggestions), 1)

        response["suggestions"][0]["issue"] = "Unused variable other_name"
        _, unsupported = validate_ai_response(
            json.dumps(response),
            "unused_value = 1\n",
            [],
        )
        self.assertEqual(unsupported, [])

    def test_invalid_ai_json_is_rejected(self):
        summary, suggestions = validate_ai_response("not json", "value = 1", [])
        self.assertIsNone(summary)
        self.assertEqual(suggestions, [])

    def test_non_json_constants_and_unsupported_suggestion_fields_are_rejected(self):
        summary, suggestions = validate_ai_response(
            '{"executive_summary":"Review complete.",'
            '"suggestions":[],"extra":NaN}',
            "value = 1",
            [],
        )
        self.assertIsNone(summary)
        self.assertEqual(suggestions, [])

        response = {
            "executive_summary": "Review complete.",
            "suggestions": [
                {
                    "line": 1,
                    "severity": "Low",
                    "category": "Code Quality",
                    "issue": "Possible simplification",
                    "explanation": "This could be simplified.",
                    "evidence": "value = 1",
                    "recommendation": "Simplify it.",
                    "confidence": "certain",
                }
            ],
        }
        _, suggestions = validate_ai_response(
            json.dumps(response),
            "value = 1",
            [],
        )
        self.assertEqual(suggestions, [])

    def test_malformed_tool_output_is_ignored_without_inventing_findings(self):
        findings = collect_confirmed_findings(
            "module.py",
            [
                None,
                {
                    "tool": "ruff",
                    "status": "Issues Found",
                    "message": "not valid JSON",
                },
                {
                    "tool": "bandit",
                    "status": "Issues Found",
                    "message": json.dumps(
                        {
                            "results": [
                                {
                                    "issue_severity": "UNKNOWN",
                                    "issue_text": "Invalid severity",
                                    "test_id": "B999",
                                    "line_number": 2,
                                }
                            ]
                        }
                    ),
                },
                {"tool": "mypy", "status": "Issues Found"},
            ],
            [None, {"line": 0, "severity": "High"}],
        )
        self.assertEqual(findings, [])

    def test_ai_summary_cannot_make_unvalidated_unused_variable_claims(self):
        response = {
            "executive_summary": "The value variable is unused.",
            "suggestions": [],
        }
        summary, suggestions = validate_ai_response(
            json.dumps(response),
            "value = 1\nprint(value)\n",
            [],
        )
        self.assertIsNone(summary)
        self.assertEqual(suggestions, [])


if __name__ == "__main__":
    unittest.main()
