import importlib
import unittest
from unittest.mock import patch


class TestEntrypoints(unittest.TestCase):
    def test_demo_modules_do_not_run_work_or_create_clients_on_import(self):
        with (
            patch("groq.Groq") as groq_factory,
            patch("static_analysis.analyzer.analyze_code") as analyze_code,
            patch("reviewer.review_code") as review_code,
        ):
            for module_name in (
                "test_groq",
                "test_reviewer",
                "test_static",
                "static_analysis.static",
            ):
                importlib.import_module(module_name)

        groq_factory.assert_not_called()
        analyze_code.assert_not_called()
        review_code.assert_not_called()


if __name__ == "__main__":
    unittest.main()
