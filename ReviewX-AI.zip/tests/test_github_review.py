import unittest
from unittest.mock import Mock, patch

from core.findings import AISuggestion, ConfirmedFinding
from integrations.github_client import (
    ChangedFile,
    GitHubAPIError,
    GitHubInputError,
    PullRequestMetadata,
)
from integrations.github_review import analyze_pull_request, map_diff_lines
from reviewer import ReviewResult

_HEAD_SHA = "b" * 40


def _pr() -> PullRequestMetadata:
    return PullRequestMetadata(
        number=7,
        title="Review changes",
        body="Description",
        author="octocat",
        base_branch="main",
        head_branch="feature",
        base_sha="a" * 40,
        head_sha=_HEAD_SHA,
        url="https://github.com/octocat/sample/pull/7",
    )


def _file(
    filename: str,
    *,
    status: str = "modified",
    additions: int = 1,
    deletions: int = 0,
    patch: str | None = "@@ -1 +1 @@\n-old\n+new",
    size: int | None = 10,
    previous_filename: str | None = None,
) -> ChangedFile:
    return ChangedFile(
        filename=filename,
        status=status,
        additions=additions,
        deletions=deletions,
        changes=additions + deletions,
        patch=patch,
        previous_filename=previous_filename,
        sha="c" * 40,
        size=size,
    )


def _file_result(filename: str, line: int = 2) -> ReviewResult:
    confirmed: ConfirmedFinding = {
        "filename": filename,
        "line": line,
        "severity": "High",
        "category": "Bug Detection",
        "issue": "Confirmed bug",
        "explanation": "Static check found a defect.",
        "source": "Confirmed static",
    }
    suggestion: AISuggestion = {
        "line": line,
        "severity": "Low",
        "category": "Code Quality",
        "issue": "Optional suggestion",
        "explanation": "This could be clearer.",
        "recommendation": "Use a descriptive name.",
        "source": "AI suggestion",
    }
    return {
        "filename": filename,
        "static_analysis": [],
        "bug_detection": [],
        "confirmed_findings": [confirmed],
        "ai_suggestions": [suggestion],
        "ai_summary": "Review summary.",
        "ai_review": "Review summary.",
        "ai_review_status": "Completed",
        "ai_review_error": None,
    }


class TestGitHubReview(unittest.TestCase):
    def test_diff_mapping_includes_only_lines_from_complete_hunks(self):
        mapped = map_diff_lines(
            "@@ -1,2 +1,3 @@\n context\n-old\n+new\n+added",
            additions=2,
            deletions=1,
        )
        self.assertTrue(mapped["complete"])
        self.assertEqual(mapped["right_lines"], [1, 2, 3])

        truncated = map_diff_lines(
            "@@ -1 +1,2 @@\n-old\n+new",
            additions=2,
            deletions=1,
        )
        self.assertFalse(truncated["complete"])
        self.assertEqual(truncated["right_lines"], [])
        self.assertFalse(map_diff_lines(None, 1, 0)["complete"])

    def test_pr_review_skips_deleted_unsupported_and_oversized_files(self):
        changed_files = [
            _file(
                "src/renamed.py",
                status="renamed",
                additions=2,
                deletions=1,
                patch="@@ -1 +1,2 @@\n-old\n+new\n+added",
                previous_filename="src/old.py",
            ),
            _file("removed.py", status="removed", patch=None),
            _file("README.md", patch=None),
            _file("large.py", size=102401, patch=None),
            _file("missing.py", patch=None),
            _file("no_patch.py", patch=None),
        ]
        client = Mock()
        client.list_changed_files.return_value = changed_files

        def get_source(owner: str, repository: str, path: str, ref: str) -> str:
            if path == "missing.py":
                raise GitHubAPIError("The GitHub resource was not found.")
            self.assertEqual(ref, _HEAD_SHA)
            return f"value = {path!r}\n"

        client.get_file_content.side_effect = get_source
        review_results = [
            _file_result("src/renamed.py", 2),
            _file_result("no_patch.py", 1),
        ]
        progress: list[tuple[str, int, int]] = []
        with patch(
            "integrations.github_review.review_sources",
            return_value=review_results,
        ) as review_sources:
            result = analyze_pull_request(
                client,
                "octocat",
                "sample",
                _pr(),
                allow_ai=True,
                on_progress=lambda stage, completed, total: progress.append(
                    (stage, completed, total)
                ),
            )

        self.assertEqual(result["changed_file_count"], 6)
        self.assertEqual(result["reviewed_file_count"], 2)
        self.assertEqual(result["review_status"], "Partial")
        self.assertEqual(result["files"][0]["previous_filename"], "src/old.py")
        self.assertTrue(result["files"][0]["diff_complete"])
        self.assertFalse(result["files"][-1]["diff_complete"])
        self.assertEqual(
            [item["filename"] for item in result["files"] if item["reviewed"]],
            ["src/renamed.py", "no_patch.py"],
        )
        self.assertEqual(result["confirmed_findings_count"], 2)
        self.assertEqual(result["ai_suggestions_count"], 2)
        review_sources.assert_called_once()
        self.assertEqual(review_sources.call_args.kwargs["allow_ai"], True)
        self.assertEqual(
            list(review_sources.call_args.args[0]),
            ["src/renamed.py", "no_patch.py"],
        )
        self.assertEqual(
            progress[-1],
            ("fetch", 6, 6),
        )

    def test_binary_or_invalid_utf8_source_is_skipped_safely(self):
        client = Mock()
        client.list_changed_files.return_value = [_file("module.py", patch=None)]
        client.get_file_content.side_effect = GitHubAPIError(
            "The PR source file is not valid UTF-8 content."
        )

        with patch("integrations.github_review.review_sources") as review_sources:
            result = analyze_pull_request(client, "octocat", "sample", _pr())

        self.assertEqual(result["reviewed_file_count"], 0)
        self.assertEqual(result["review_status"], "No eligible Python files")
        self.assertIn("UTF-8", result["files"][0]["skip_reason"])
        review_sources.assert_not_called()

    def test_api_rate_limit_stops_repeated_source_fetches(self):
        client = Mock()
        client.list_changed_files.return_value = [
            _file("first.py", patch=None),
            _file("second.py", patch=None),
        ]
        client.get_file_content.side_effect = GitHubAPIError(
            "GitHub API rate limit reached. Try again later.",
            403,
            stop_fetching=True,
        )

        with patch("integrations.github_review.review_sources") as review_sources:
            result = analyze_pull_request(client, "octocat", "sample", _pr())

        self.assertEqual(client.get_file_content.call_count, 1)
        self.assertEqual(result["reviewed_file_count"], 0)
        self.assertIn("rate limit", result["files"][0]["skip_reason"])
        self.assertIn("stopped", result["files"][1]["skip_reason"])
        review_sources.assert_not_called()

    def test_pull_request_file_limit_is_enforced_before_source_fetch(self):
        client = Mock()
        client.list_changed_files.return_value = [
            _file(f"{index}.py") for index in range(101)
        ]

        with self.assertRaisesRegex(GitHubInputError, "100 changed-file"):
            analyze_pull_request(client, "octocat", "sample", _pr())


if __name__ == "__main__":
    unittest.main()
