import json
import subprocess
import sys
import unittest
from pathlib import Path
from unittest.mock import patch

from static_analysis.analyzer import analyze_code, run_tool


class TestStaticAnalyzer(unittest.TestCase):
    def test_syntax_error_stops_before_external_tools(self):
        with patch("static_analysis.analyzer.run_tool") as run_mock:
            results = analyze_code("def broken(:")

        self.assertEqual(len(results), 1)
        self.assertEqual(results[0]["status"], "Issues Found")
        self.assertEqual(results[0]["tool"], "Python AST")
        run_mock.assert_not_called()

    def test_empty_and_oversized_input_are_rejected(self):
        empty_result = analyze_code("")
        with patch("static_analysis.analyzer.run_tool") as run_mock:
            oversized_result = analyze_code("x = 1", max_size_bytes=2)

        self.assertEqual(empty_result[0]["tool"], "Input Validation")
        self.assertEqual(empty_result[0]["status"], "Error")
        self.assertEqual(oversized_result[0]["status"], "Error")
        run_mock.assert_not_called()

    def test_valid_source_returns_syntax_and_each_tool_result(self):
        expected = [
            {
                "tool": "ruff",
                "status": "Passed",
                "message": "ok",
                "exit_code": 0,
            },
            {
                "tool": "bandit",
                "status": "Passed",
                "message": "ok",
                "exit_code": 0,
            },
            {
                "tool": "mypy",
                "status": "Passed",
                "message": "ok",
                "exit_code": 0,
            },
        ]
        with patch(
            "static_analysis.analyzer.run_tool",
            side_effect=expected,
        ) as run_mock:
            results = analyze_code("value = 1")

        self.assertEqual([item["status"] for item in results], ["Passed"] * 4)
        self.assertEqual(run_mock.call_count, 3)

    def test_unknown_tool_is_rejected_without_subprocess(self):
        with patch("static_analysis.analyzer.subprocess.run") as run_mock:
            result = run_tool("unknown", "value = 1")

        self.assertEqual(result["status"], "Error")
        self.assertIn("not allowed", result["message"])
        run_mock.assert_not_called()

    def test_missing_tool_is_reported_without_subprocess(self):
        with (
            patch("static_analysis.analyzer.importlib.util.find_spec", return_value=None),
            patch("static_analysis.analyzer.subprocess.run") as run_mock,
        ):
            result = run_tool("ruff", "value = 1")

        self.assertEqual(result["status"], "Error")
        self.assertIn("not installed", result["message"])
        run_mock.assert_not_called()

    def test_ruff_findings_are_not_mislabeled_as_tool_errors(self):
        report = json.dumps([{"code": "F821", "message": "undefined name"}])
        completed = subprocess.CompletedProcess(
            args=[],
            returncode=1,
            stdout=report,
            stderr="",
        )
        with (
            patch(
                "static_analysis.analyzer.importlib.util.find_spec",
                return_value=object(),
            ),
            patch(
                "static_analysis.analyzer.subprocess.run",
                return_value=completed,
            ) as run_mock,
        ):
            result = run_tool("ruff", "value = missing")

        self.assertEqual(result["status"], "Issues Found")
        self.assertEqual(result["exit_code"], 1)
        command = run_mock.call_args.args[0]
        self.assertEqual(command[0], sys.executable)
        self.assertEqual(run_mock.call_args.kwargs["shell"], False)
        self.assertEqual(run_mock.call_args.kwargs["check"], False)
        self.assertFalse(Path(command[-1]).exists())

    def test_mypy_findings_are_distinguished_from_tool_failure(self):
        completed = subprocess.CompletedProcess(
            args=[],
            returncode=1,
            stdout="submitted.py:1: error: Incompatible types [assignment]",
            stderr="",
        )
        with (
            patch(
                "static_analysis.analyzer.importlib.util.find_spec",
                return_value=object(),
            ),
            patch(
                "static_analysis.analyzer.subprocess.run",
                return_value=completed,
            ),
        ):
            result = run_tool("mypy", "value: int = 'wrong'")

        self.assertEqual(result["status"], "Issues Found")

    def test_bandit_findings_are_distinguished_from_tool_failure(self):
        report = json.dumps(
            {
                "errors": [],
                "results": [{"issue_text": "Use of insecure function"}],
            }
        )
        completed = subprocess.CompletedProcess(
            args=[],
            returncode=1,
            stdout=report,
            stderr="",
        )
        with (
            patch(
                "static_analysis.analyzer.importlib.util.find_spec",
                return_value=object(),
            ),
            patch(
                "static_analysis.analyzer.subprocess.run",
                return_value=completed,
            ),
        ):
            result = run_tool("bandit", "value = 1")

        self.assertEqual(result["status"], "Issues Found")

    def test_non_finding_exit_code_one_is_a_tool_error(self):
        completed = subprocess.CompletedProcess(
            args=[],
            returncode=1,
            stdout="module failed to start",
            stderr="",
        )
        with (
            patch(
                "static_analysis.analyzer.importlib.util.find_spec",
                return_value=object(),
            ),
            patch(
                "static_analysis.analyzer.subprocess.run",
                return_value=completed,
            ),
        ):
            result = run_tool("ruff", "value = 1")

        self.assertEqual(result["status"], "Error")

    def test_timeout_is_reported_and_temporary_source_is_removed(self):
        source_paths: list[Path] = []

        def timeout(command, **kwargs):
            source_paths.append(Path(command[-1]))
            raise subprocess.TimeoutExpired(command, kwargs["timeout"])

        with (
            patch(
                "static_analysis.analyzer.importlib.util.find_spec",
                return_value=object(),
            ),
            patch("static_analysis.analyzer.subprocess.run", side_effect=timeout),
        ):
            result = run_tool("ruff", "value = 1")

        self.assertEqual(result["status"], "Error")
        self.assertIn("timed out", result["message"])
        self.assertEqual(len(source_paths), 1)
        self.assertFalse(source_paths[0].exists())


if __name__ == "__main__":
    unittest.main()
