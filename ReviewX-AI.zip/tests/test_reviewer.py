import json
import unittest
from unittest.mock import Mock, patch

from groq import APITimeoutError

from reviewer import get_groq_client, review_code, review_sources


def _settings(**overrides: str) -> dict[str, str | None]:
    settings: dict[str, str | None] = {
        "ENABLE_AI_REVIEW": "false",
        "MAX_CODE_SIZE": "102400",
        "GROQ_TIMEOUT": "60",
        "GROQ_MODEL": "openai/gpt-oss-20b",
    }
    settings.update(overrides)
    return settings


class TestReviewer(unittest.TestCase):
    def test_multiple_sources_are_reviewed_independently(self):
        reviewed: list[tuple[str, bool, str]] = []
        progress: list[tuple[int, int]] = []

        def fake_review(code: str, allow_ai: bool, filename: str):
            reviewed.append((code, allow_ai, filename))
            return {"filename": filename}

        with patch("reviewer.review_code", side_effect=fake_review):
            results = review_sources(
                {"a.py": "first = 1", "pkg/b.py": "second = 2"},
                allow_ai=True,
                on_progress=lambda completed, total: progress.append(
                    (completed, total)
                ),
            )

        self.assertEqual(
            reviewed,
            [
                ("first = 1", True, "a.py"),
                ("second = 2", True, "pkg/b.py"),
            ],
        )
        self.assertEqual(progress, [(1, 2), (2, 2)])
        self.assertEqual([result["filename"] for result in results], ["a.py", "pkg/b.py"])

    def test_ai_disabled_does_not_create_a_client(self):
        with (
            patch("reviewer.load_settings", return_value=_settings()),
            patch("reviewer.analyze_code", return_value=[]),
            patch("reviewer.detect_bugs", return_value=[]),
            patch("reviewer.get_groq_client") as client_factory,
        ):
            result = review_code("value = 1", allow_ai=False)

        self.assertEqual(result["ai_review_status"], "Skipped")
        self.assertIsNone(result["ai_review"])
        client_factory.assert_not_called()

    def test_missing_api_key_is_reported_without_a_request(self):
        settings = _settings(ENABLE_AI_REVIEW="true")
        with (
            patch("reviewer.load_settings", return_value=settings),
            patch("reviewer.analyze_code", return_value=[]),
            patch("reviewer.detect_bugs", return_value=[]),
        ):
            result = review_code("value = 1", allow_ai=True)

        self.assertEqual(result["ai_review_status"], "Failed")
        self.assertEqual(
            result["ai_review_error"],
            "GROQ_API_KEY is missing from .env.",
        )
        self.assertIsNone(result["ai_review"])

    def test_missing_model_is_reported(self):
        settings = _settings(ENABLE_AI_REVIEW="true", GROQ_MODEL="")
        with (
            patch("reviewer.load_settings", return_value=settings),
            patch("reviewer.analyze_code", return_value=[]),
            patch("reviewer.detect_bugs", return_value=[]),
            patch("reviewer.get_groq_client") as client_factory,
        ):
            result = review_code("value = 1", allow_ai=True)

        self.assertEqual(result["ai_review_status"], "Failed")
        self.assertIn("GROQ_MODEL", result["ai_review_error"])
        client_factory.assert_not_called()

    def test_invalid_source_and_size_are_rejected_before_analysis(self):
        settings = _settings(MAX_CODE_SIZE="2")
        with (
            patch("reviewer.load_settings", return_value=settings),
            patch("reviewer.analyze_code") as analyzer,
            patch("reviewer.detect_bugs") as detector,
        ):
            empty_result = review_code("")
            large_result = review_code("long source", allow_ai=False)

        self.assertEqual(empty_result["ai_review_status"], "Invalid input")
        self.assertEqual(large_result["ai_review_status"], "Invalid input")
        analyzer.assert_not_called()
        detector.assert_not_called()

    def test_configured_source_size_limit_is_enforced(self):
        settings = _settings(MAX_CODE_SIZE="2")
        with (
            patch("reviewer.load_settings", return_value=settings),
            patch("reviewer.analyze_code") as analyzer,
            patch("reviewer.detect_bugs") as detector,
        ):
            result = review_code("value = 1")

        self.assertEqual(result["ai_review_status"], "Invalid input")
        self.assertIn("maximum allowed size", result["ai_review_error"])
        analyzer.assert_not_called()
        detector.assert_not_called()

    def test_groq_client_uses_file_settings_and_timeout(self):
        settings = _settings()
        settings["GROQ_API_KEY"] = "mocked-value"
        settings["GROQ_TIMEOUT"] = "15"
        with patch("reviewer.Groq") as groq_factory:
            get_groq_client(settings)

        groq_factory.assert_called_once_with(
            api_key="mocked-value",
            timeout=15,
        )

    def test_successful_ai_review_includes_static_and_bug_findings(self):
        settings = _settings(ENABLE_AI_REVIEW="true")
        client = Mock()
        client.chat.completions.create.return_value.choices = [
            Mock(
                message=Mock(
                    content=json.dumps(
                        {
                            "executive_summary": "Review complete.",
                            "suggestions": [
                                {
                                    "line": 2,
                                    "severity": "Low",
                                    "category": "Code Quality",
                                    "issue": "Name the literal value",
                                    "explanation": (
                                        "A named constant may improve clarity."
                                    ),
                                    "evidence": "result = 2",
                                    "recommendation": (
                                        "Introduce a descriptive constant."
                                    ),
                                }
                            ],
                        }
                    )
                )
            )
        ]
        with (
            patch("reviewer.load_settings", return_value=settings),
            patch(
                "reviewer.analyze_code",
                return_value=[
                    {
                        "tool": "Python AST",
                        "status": "Passed",
                        "message": "ok",
                        "exit_code": None,
                    }
                ],
            ),
            patch(
                "reviewer.detect_bugs",
                return_value=[
                    {
                        "line": 1,
                        "severity": "High",
                        "issue": "Division by zero",
                        "explanation": "Literal zero divisor.",
                    }
                ],
            ),
            patch("reviewer.get_groq_client", return_value=client),
        ):
            result = review_code(
                "value = 1 / 0\nresult = 2",
                allow_ai=True,
                filename="pkg/module.py",
            )

        self.assertEqual(result["ai_summary"], "Review complete.")
        self.assertIn("Executive Summary", result["ai_review"])
        self.assertEqual(result["ai_review_status"], "Completed")
        self.assertEqual(len(result["static_analysis"]), 1)
        self.assertEqual(len(result["bug_detection"]), 1)
        self.assertEqual(
            result["confirmed_findings"][0]["filename"],
            "pkg/module.py",
        )
        self.assertEqual(len(result["ai_suggestions"]), 1)
        self.assertIn("Introduce a descriptive constant.", result["ai_review"])
        prompt = client.chat.completions.create.call_args.kwargs["messages"][1][
            "content"
        ]
        self.assertIn("never contradict", prompt)
        self.assertIn("Do not report a variable as unused", prompt)
        client.close.assert_called_once()

    def test_invalid_ai_response_is_not_displayed_as_a_review(self):
        settings = _settings(ENABLE_AI_REVIEW="true", GROQ_API_KEY="test-key")
        client = Mock()
        client.chat.completions.create.return_value.choices = [
            Mock(message=Mock(content="unsupported unstructured finding"))
        ]
        static_results = [
            {
                "tool": "ruff",
                "status": "Issues Found",
                "message": json.dumps(
                    [
                        {
                            "code": "F821",
                            "message": "Undefined name",
                            "location": {"row": 1, "column": 1},
                        }
                    ]
                ),
                "exit_code": 1,
            }
        ]
        with (
            patch("reviewer.load_settings", return_value=settings),
            patch("reviewer.analyze_code", return_value=static_results),
            patch("reviewer.detect_bugs", return_value=[]),
            patch("reviewer.get_groq_client", return_value=client),
        ):
            result = review_code("value = 1", allow_ai=True)

        self.assertEqual(result["ai_review_status"], "Invalid response")
        self.assertIsNone(result["ai_summary"])
        self.assertIsNone(result["ai_review"])
        self.assertEqual(result["ai_suggestions"], [])
        self.assertIn("validated JSON", result["ai_review_error"])
        self.assertEqual(result["static_analysis"], static_results)
        self.assertEqual(len(result["confirmed_findings"]), 1)
        self.assertEqual(
            result["confirmed_findings"][0]["source"],
            "Confirmed static",
        )
        client.close.assert_called_once()

    def test_api_timeout_returns_partial_local_results(self):
        settings = _settings(
            ENABLE_AI_REVIEW="true",
            GROQ_API_KEY="test-key",
        )
        client = Mock()
        client.chat.completions.create.side_effect = APITimeoutError(
            request=Mock()
        )
        with (
            patch("reviewer.load_settings", return_value=settings),
            patch("reviewer.analyze_code", return_value=[]),
            patch("reviewer.detect_bugs", return_value=[]),
            patch("reviewer.get_groq_client", return_value=client),
        ):
            result = review_code("value = 1", allow_ai=True)

        self.assertEqual(result["ai_review_status"], "Failed")
        self.assertEqual(
            result["ai_review_error"],
            "The Groq request timed out.",
        )
        self.assertEqual(result["static_analysis"], [])
        client.close.assert_called_once()


if __name__ == "__main__":
    unittest.main()
