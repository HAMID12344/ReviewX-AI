import base64
import unittest
from urllib.parse import parse_qs

import httpx

from integrations.github_client import (
    GitHubAPIError,
    GitHubClient,
    GitHubInputError,
    parse_repository_identifier,
)

_SHA = "a" * 40


def _repository_payload(name: str = "sample") -> dict[str, object]:
    return {
        "owner": {"login": "octocat"},
        "name": name,
        "full_name": f"octocat/{name}",
        "private": False,
        "default_branch": "main",
    }


def _pull_request_payload() -> dict[str, object]:
    return {
        "number": 7,
        "title": "Improve checks",
        "body": "Review description.",
        "user": {"login": "octocat"},
        "base": {"ref": "main", "sha": _SHA},
        "head": {"ref": "feature", "sha": "b" * 40},
    }


class TestGitHubClient(unittest.TestCase):
    def test_authentication_and_repository_retrieval_use_the_token_header(self):
        requests: list[httpx.Request] = []

        def handler(request: httpx.Request) -> httpx.Response:
            requests.append(request)
            if request.url.path == "/user":
                return httpx.Response(200, json={"login": "octocat"})
            return httpx.Response(200, json=[_repository_payload()])

        with GitHubClient(
            "fake-test-token",
            transport=httpx.MockTransport(handler),
        ) as client:
            self.assertEqual(client.authenticate(), "octocat")
            repositories = client.list_repositories()

        self.assertEqual([repo.full_name for repo in repositories], ["octocat/sample"])
        self.assertTrue(
            all(request.headers["Authorization"] == "Bearer fake-test-token"
                for request in requests)
        )

    def test_invalid_token_is_reported_without_echoing_credential(self):
        secret = "fake-invalid-token"

        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(401, json={"message": "Bad credentials"})

        with GitHubClient(
            secret,
            transport=httpx.MockTransport(handler),
        ) as client, self.assertRaises(GitHubAPIError) as raised:
            client.authenticate()

        self.assertEqual(str(raised.exception), "GitHub authentication failed.")
        self.assertNotIn(secret, str(raised.exception))

    def test_repository_input_accepts_owner_name_and_github_https_urls_only(self):
        self.assertEqual(parse_repository_identifier("octocat/sample"), ("octocat", "sample"))
        self.assertEqual(
            parse_repository_identifier("https://github.com/octocat/sample.git"),
            ("octocat", "sample"),
        )
        for value in (
            "https://example.com/octocat/sample",
            "https://github.com.evil.example/octocat/sample",
            "octocat/../sample",
            "octocat/sample/extra",
        ):
            with self.subTest(value=value), self.assertRaises(GitHubInputError):
                parse_repository_identifier(value)

    def test_repository_pagination_is_bounded_and_accumulates_pages(self):
        def handler(request: httpx.Request) -> httpx.Response:
            page = int(parse_qs(request.url.query.decode())["page"][0])
            if page == 1:
                return httpx.Response(
                    200,
                    json=[_repository_payload(f"repo-{index}") for index in range(100)],
                )
            return httpx.Response(200, json=[_repository_payload("last")])

        with GitHubClient(
            "fake-test-token",
            transport=httpx.MockTransport(handler),
        ) as client:
            repositories = client.list_repositories()

        self.assertEqual(len(repositories), 101)
        self.assertEqual(repositories[-1].name, "last")

    def test_pull_request_and_changed_file_pagination(self):
        requests: list[tuple[str, int]] = []

        def handler(request: httpx.Request) -> httpx.Response:
            page = int(parse_qs(request.url.query.decode())["page"][0])
            requests.append((request.url.path, page))
            if request.url.path.endswith("/pulls"):
                page_items = [_pull_request_payload() for _ in range(100)]
                return httpx.Response(200, json=page_items if page == 1 else [])
            if request.url.path.endswith("/pulls/7/files"):
                page_items = [
                    {
                        "filename": f"module-{index}.py",
                        "status": "modified",
                        "additions": 0,
                        "deletions": 0,
                        "changes": 0,
                        "patch": None,
                    }
                    for index in range(100)
                ]
                if page > 1:
                    page_items = [
                        {
                            "filename": "last.py",
                            "status": "added",
                            "additions": 0,
                            "deletions": 0,
                            "changes": 0,
                            "patch": None,
                        }
                    ]
                return httpx.Response(200, json=page_items)
            raise AssertionError(f"Unexpected API path: {request.url.path}")

        with GitHubClient(
            "fake-test-token",
            transport=httpx.MockTransport(handler),
        ) as client:
            pull_requests = client.list_pull_requests("octocat", "sample")
            changed_files = client.list_changed_files("octocat", "sample", 7)

        self.assertEqual(len(pull_requests), 100)
        self.assertEqual(len(changed_files), 101)
        self.assertIn(("/repos/octocat/sample/pulls", 2), requests)
        self.assertIn(("/repos/octocat/sample/pulls/7/files", 2), requests)

    def test_pull_requests_changed_files_and_source_are_retrieved_from_api_paths(self):
        expected_content = b"value = 1\n"

        def handler(request: httpx.Request) -> httpx.Response:
            if request.url.path.endswith("/pulls"):
                return httpx.Response(200, json=[_pull_request_payload()])
            if request.url.path.endswith("/pulls/7/files"):
                return httpx.Response(
                    200,
                    json=[
                        {
                            "filename": "src/module.py",
                            "status": "modified",
                            "additions": 1,
                            "deletions": 0,
                            "changes": 1,
                            "patch": "@@ -1 +1,2 @@\n value = 0\n+value = 1",
                            "sha": _SHA,
                            "size": len(expected_content),
                        }
                    ],
                )
            if request.url.path.endswith("/contents/src/module.py"):
                self.assertEqual(request.url.params["ref"], "b" * 40)
                return httpx.Response(
                    200,
                    json={
                        "type": "file",
                        "size": len(expected_content),
                        "encoding": "base64",
                        "content": base64.b64encode(expected_content).decode("ascii"),
                    },
                )
            raise AssertionError(f"Unexpected API path: {request.url.path}")

        with GitHubClient(
            "fake-test-token",
            transport=httpx.MockTransport(handler),
        ) as client:
            pull_requests = client.list_pull_requests("octocat", "sample")
            changed_files = client.list_changed_files("octocat", "sample", 7)
            source = client.get_file_content(
                "octocat",
                "sample",
                changed_files[0].filename,
                "b" * 40,
            )

        self.assertEqual(pull_requests[0].number, 7)
        self.assertEqual(pull_requests[0].base_sha, _SHA)
        self.assertEqual(changed_files[0].status, "modified")
        self.assertEqual(source, "value = 1\n")

    def test_rate_limit_and_oversized_response_are_reported_safely(self):
        def rate_limit(request: httpx.Request) -> httpx.Response:
            return httpx.Response(
                403,
                headers={"X-RateLimit-Remaining": "0"},
                json={"message": "rate limit"},
            )

        with GitHubClient(
            "fake-test-token",
            transport=httpx.MockTransport(rate_limit),
        ) as client, self.assertRaisesRegex(GitHubAPIError, "rate limit"):
            client.authenticate()

        def oversized(request: httpx.Request) -> httpx.Response:
            return httpx.Response(
                200,
                headers={"Content-Length": "50"},
                content=b'{"login":"octocat"}',
            )

        with GitHubClient(
            "fake-test-token",
            max_response_bytes=10,
            transport=httpx.MockTransport(oversized),
        ) as client, self.assertRaisesRegex(GitHubAPIError, "size limit"):
            client.authenticate()

    def test_file_paths_and_oversized_source_are_rejected(self):
        with GitHubClient(
            "fake-test-token",
            transport=httpx.MockTransport(
                lambda request: httpx.Response(
                    200,
                    json={
                        "type": "file",
                        "size": 102401,
                        "encoding": "base64",
                        "content": "",
                    },
                )
            ),
        ) as client:
            with self.assertRaises(GitHubInputError):
                client.get_file_content("octocat", "sample", "../escape.py", _SHA)
            with self.assertRaisesRegex(GitHubAPIError, "source file exceeds"):
                client.get_file_content("octocat", "sample", "large.py", _SHA)

    def test_review_submission_is_comment_event_and_uses_mock_transport(self):
        posted: list[str] = []

        def handler(request: httpx.Request) -> httpx.Response:
            posted.append(request.read().decode("utf-8"))
            return httpx.Response(201, json={"id": 12, "state": "commented"})

        with GitHubClient(
            "fake-test-token",
            transport=httpx.MockTransport(handler),
        ) as client:
            result = client.submit_review(
                "octocat",
                "sample",
                7,
                _SHA,
                "Review summary.",
                [{"path": "src/module.py", "line": 2, "side": "RIGHT", "body": "Note"}],
                approved=True,
            )

        self.assertEqual(result["id"], 12)
        self.assertEqual(len(posted), 1)
        self.assertIn('"event":"COMMENT"', posted[0])
        self.assertIn('"line":2', posted[0])

    def test_review_submission_requires_explicit_approval(self):
        requests: list[httpx.Request] = []

        def handler(request: httpx.Request) -> httpx.Response:
            requests.append(request)
            return httpx.Response(201, json={"id": 18})

        transport = httpx.MockTransport(handler)
        with (
            GitHubClient("fake-test-token", transport=transport) as client,
            self.assertRaisesRegex(GitHubInputError, "approval"),
        ):
            client.submit_review(
                "octocat",
                "sample",
                7,
                _SHA,
                "Review summary.",
                [],
            )
        self.assertEqual(requests, [])


if __name__ == "__main__":
    unittest.main()
