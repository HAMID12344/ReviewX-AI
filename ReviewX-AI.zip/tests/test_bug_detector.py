
import unittest

from core.bug_detector import detect_bugs


class TestBugDetector(unittest.TestCase):
    def test_division_by_zero(self):
        findings = detect_bugs("\nresult = 10 / 0")

        self.assertEqual(len(findings), 1)
        self.assertEqual(findings[0]["line"], 2)
        self.assertEqual(findings[0]["issue"], "Division by zero")
        self.assertEqual(findings[0]["severity"], "High")

    def test_normal_division(self):
        findings = detect_bugs("result = 10 / 2")
        self.assertEqual(findings, [])

    def test_floor_division_and_modulo_by_zero(self):
        findings = detect_bugs("a = 10 // -0\nb = 10 % 0")

        self.assertEqual(
            [finding["issue"] for finding in findings],
            ["Division by zero", "Division by zero"],
        )

    def test_broad_exception(self):
        code = """
try:
    print("Hello")
except Exception:
    pass
"""
        findings = detect_bugs(code)
        self.assertTrue(
            any(
                item["issue"] == "Broad exception handling"
                for item in findings
            )
        )

    def test_bare_except(self):
        findings = detect_bugs("try:\n    work()\nexcept:\n    pass")

        self.assertEqual(findings[0]["issue"], "Bare except clause")
        self.assertEqual(findings[0]["line"], 3)

    def test_base_exception_is_high_severity(self):
        findings = detect_bugs(
            "try:\n    work()\nexcept BaseException:\n    pass"
        )

        self.assertEqual(findings[0]["severity"], "High")
        self.assertEqual(findings[0]["issue"], "Broad exception handling")

    def test_suspicious_assertion(self):
        findings = detect_bugs("assert False\nassert 0\nassert True")

        self.assertEqual(len(findings), 2)
        self.assertTrue(
            all(finding["issue"] == "Suspicious assertion" for finding in findings)
        )

    def test_syntax_error(self):
        findings = detect_bugs("if True print('Hello')")

        self.assertEqual(findings[0]["issue"], "Syntax error")
        self.assertEqual(findings[0]["line"], 1)

    def test_empty_input(self):
        for source in ("", "  ", None):
            with self.subTest(source=source):
                findings = detect_bugs(source)

                self.assertEqual(findings[0]["issue"], "Invalid input")


if __name__ == "__main__":
    unittest.main()
