import io
import stat
import unittest
import zipfile
from unittest.mock import patch

from core.uploads import (
    UploadValidationError,
    extract_python_files,
    read_python_upload,
)


def _zip_bytes(entries: dict[str, bytes]) -> bytes:
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w", zipfile.ZIP_DEFLATED) as archive:
        for filename, content in entries.items():
            archive.writestr(filename, content)
    return buffer.getvalue()


class TestUploads(unittest.TestCase):
    def test_individual_python_file_is_decoded_and_bom_is_removed(self):
        source = read_python_upload("module.py", b"\xef\xbb\xbfvalue = 1")
        self.assertEqual(source, "value = 1")

    def test_individual_upload_rejects_bad_extension_empty_and_oversize(self):
        with self.assertRaises(UploadValidationError):
            read_python_upload("module.txt", b"value = 1")
        with self.assertRaises(UploadValidationError):
            read_python_upload("module.py", b"")
        with (
            patch("core.uploads.MAX_CODE_SIZE_BYTES", 2),
            self.assertRaises(UploadValidationError),
        ):
            read_python_upload("module.py", b"value = 1")

    def test_zip_returns_only_python_files_with_relative_names(self):
        archive = _zip_bytes(
            {
                "src/main.py": b"main = True",
                "README.txt": b"not analyzed",
                "tests/test_main.PY": b"test = True",
            }
        )

        self.assertEqual(
            extract_python_files(archive),
            {
                "src/main.py": "main = True",
                "tests/test_main.PY": "test = True",
            },
        )

    def test_zip_rejects_posix_and_windows_path_traversal(self):
        for filename in ("../escape.py", r"..\escape.py", r"C:\temp\module.py"):
            with self.subTest(filename=filename):
                archive = _zip_bytes({filename: b"value = 1"})
                with self.assertRaises(UploadValidationError):
                    extract_python_files(archive)

    def test_zip_rejects_symbolic_links_and_duplicate_paths(self):
        buffer = io.BytesIO()
        with zipfile.ZipFile(buffer, "w") as archive:
            symbolic_link = zipfile.ZipInfo("link.py")
            symbolic_link.create_system = 3
            symbolic_link.external_attr = (stat.S_IFLNK | 0o777) << 16
            archive.writestr(symbolic_link, "target.py")
        with self.assertRaises(UploadValidationError):
            extract_python_files(buffer.getvalue())

        duplicate = io.BytesIO()
        with zipfile.ZipFile(duplicate, "w") as archive:
            archive.writestr("src.py", b"a = 1")
            archive.writestr("SRC.PY", b"b = 2")
        with self.assertRaises(UploadValidationError):
            extract_python_files(duplicate.getvalue())

    def test_zip_limits_archive_size_expansion_and_python_file_count(self):
        archive = _zip_bytes({"module.py": b"value = 123456"})
        with (
            patch("core.uploads.MAX_ARCHIVE_BYTES", 1),
            self.assertRaises(UploadValidationError),
        ):
            extract_python_files(archive)
        with (
            patch("core.uploads.MAX_ARCHIVE_UNCOMPRESSED_BYTES", 2),
            self.assertRaises(UploadValidationError),
        ):
            extract_python_files(archive)

        many_files = _zip_bytes({"a.py": b"a = 1", "b.py": b"b = 2"})
        with (
            patch("core.uploads.MAX_ARCHIVE_PYTHON_FILES", 1),
            self.assertRaises(UploadValidationError),
        ):
            extract_python_files(many_files)

    def test_zip_rejects_python_member_over_source_limit(self):
        archive = _zip_bytes({"module.py": b"value = 123456"})
        with (
            patch("core.uploads.MAX_CODE_SIZE_BYTES", 5),
            self.assertRaises(UploadValidationError),
        ):
            extract_python_files(archive)

    def test_zip_rejects_non_utf8_and_archives_without_python_files(self):
        with self.assertRaises(UploadValidationError):
            extract_python_files(_zip_bytes({"bad.py": b"\xff"}))
        with self.assertRaises(UploadValidationError):
            extract_python_files(_zip_bytes({"README.md": b"docs"}))
        with self.assertRaises(UploadValidationError):
            extract_python_files(b"not a zip")


if __name__ == "__main__":
    unittest.main()
