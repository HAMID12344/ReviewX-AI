import unittest
from unittest.mock import Mock

from core.findings import AISuggestion, ConfirmedFinding
from integrations.github_client import PullRequestMetadata
from integrations.github_comments import (
    ReviewApprovalRequired,
    ReviewComment,
    preview_review_comments,
    publish_approved_review,
)
from integrations.github_review import (
    PullRequestFileReview,
    PullRequestReview,
)
from reviewer import ReviewResult

_SHA = "b" * 40


def _review_result(filename: str) -> ReviewResult:
    finding: ConfirmedFinding = {
        "filename": filename,
        "line": 2,
        "severity": "High",
        "category": "Security",
        "issue": "Unsafe operation",
        "explanation": "A confirmed static issue.",
        "source": "Confirmed static",
    }
    suggestion: AISuggestion = {
        "line": 2,
        "severity": "Low",
        "category": "Code Quality",
        "issue": "Consider simplifying this expression.",
        "explanation": "The expression can be clearer.",
        "recommendation": "Use a named intermediate value.",
        "source": "AI suggestion",
    }
    return {
        "filename": filename,
        "static_analysis": [],
        "bug_detection": [],
        "confirmed_findings": [finding],
        "ai_suggestions": [suggestion],
        "ai_summary": "Review summary.",
        "ai_review": "Review summary.",
        "ai_review_status": "Completed",
        "ai_review_error": None,
    }


def _pull_request_review() -> PullRequestReview:
    metadata = PullRequestMetadata(
        number=8,
        title="Review change",
        body="Description",
        author="octocat",
        base_branch="main",
        head_branch="feature",
        base_sha="a" * 40,
        head_sha=_SHA,
        url="https://github.com/octocat/sample/pull/8",
    )
    reviewed_file: PullRequestFileReview = {
        "filename": "src/module.py",
        "status": "modified",
        "previous_filename": None,
        "reviewed": True,
        "skip_reason": None,
        "diff_complete": True,
        "commentable_lines": [2],
        "review": _review_result("src/module.py"),
    }
    incomplete_file: PullRequestFileReview = {
        "filename": "src/other.py",
        "status": "modified",
        "previous_filename": None,
        "reviewed": True,
        "skip_reason": None,
        "diff_complete": False,
        "commentable_lines": [],
        "review": _review_result("src/other.py"),
    }
    return {
        "repository": "octocat/sample",
        "pull_request": metadata,
        "executive_summary": "Two findings require review.",
        "changed_file_count": 2,
        "reviewed_file_count": 2,
        "confirmed_findings_count": 2,
        "ai_suggestions_count": 2,
        "category_breakdown": {"Security": 2},
        "severity_breakdown": {
            "confirmed_static": {"High": 2},
            "ai_suggestions": {"Low": 2},
        },
        "review_status": "Completed",
        "files": [reviewed_file, incomplete_file],
    }


class TestGitHubComments(unittest.TestCase):
    def test_preview_includes_only_findings_on_complete_diff_lines(self):
        comments = preview_review_comments(_pull_request_review())

        self.assertEqual(len(comments), 2)
        self.assertTrue(all(comment["path"] == "src/module.py" for comment in comments))
        self.assertTrue(all(comment["line"] == 2 for comment in comments))
        self.assertEqual(
            {comment["source"] for comment in comments},
            {"Confirmed static", "AI suggestion"},
        )
        self.assertTrue(any("unconfirmed" in comment["body"] for comment in comments))

    def test_publication_requires_explicit_approval(self):
        client = Mock()
        with self.assertRaises(ReviewApprovalRequired):
            publish_approved_review(
                client,
                _pull_request_review(),
                "Summary",
                preview_review_comments(_pull_request_review()),
            )
        client.submit_review.assert_not_called()

    def test_invalid_comment_line_is_rejected_before_publication(self):
        client = Mock()
        invalid: ReviewComment = {
            "path": "src/module.py",
            "line": 99,
            "side": "RIGHT",
            "body": "Invalid location",
            "source": "Confirmed static",
        }
        with self.assertRaisesRegex(ValueError, "not valid for the selected"):
            publish_approved_review(
                client,
                _pull_request_review(),
                "Summary",
                [invalid],
                approved=True,
            )
        client.submit_review.assert_not_called()

    def test_approved_publication_uses_comment_event_and_review_head_sha(self):
        client = Mock()
        client.submit_review.return_value = {"id": 18}
        review = _pull_request_review()
        comments = preview_review_comments(review)

        result = publish_approved_review(
            client,
            review,
            "Summary",
            comments,
            approved=True,
        )

        self.assertEqual(result["id"], 18)
        client.submit_review.assert_called_once()
        self.assertEqual(
            client.submit_review.call_args.args,
            (
                "octocat",
                "sample",
                8,
                _SHA,
                "Summary",
                [
                    {
                        "path": "src/module.py",
                        "line": 2,
                        "side": "RIGHT",
                        "body": comments[0]["body"],
                    },
                    {
                        "path": "src/module.py",
                        "line": 2,
                        "side": "RIGHT",
                        "body": comments[1]["body"],
                    },
                ],
            ),
        )


if __name__ == "__main__":
    unittest.main()
