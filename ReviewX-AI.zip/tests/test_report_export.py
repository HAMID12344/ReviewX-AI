import json
import unittest

from core.findings import collect_confirmed_findings
from reports.export import (
    build_pull_request_report_payload,
    build_report_payload,
    json_report_bytes,
    pdf_report_bytes,
)
from reviewer import ReviewResult


class TestReportExport(unittest.TestCase):
    def setUp(self):
        static_analysis = [
            {
                "tool": "ruff",
                "status": "Issues Found",
                "message": (
                    '[{"code":"F821","message":"Undefined name",'
                    '"location":{"row":1,"column":1}}]'
                ),
                "exit_code": 1,
            }
        ]
        bugs = [
            {
                "line": 2,
                "severity": "High",
                "issue": "Division by zero",
                "explanation": "Literal zero divisor.",
            }
        ]
        self.review: ReviewResult = {
            "filename": "src/module.py",
            "static_analysis": static_analysis,
            "bug_detection": bugs,
            "confirmed_findings": collect_confirmed_findings(
                "src/module.py",
                static_analysis,
                bugs,
            ),
            "ai_suggestions": [
                {
                    "line": 3,
                    "severity": "Low",
                    "category": "Performance",
                    "issue": "Optional optimization",
                    "explanation": "This is advisory.",
                    "recommendation": "Consider caching the value.",
                    "source": "AI suggestion",
                }
            ],
            "ai_summary": "Review summary.",
            "ai_review": "Review summary.",
            "ai_review_status": "Completed",
            "ai_review_error": None,
        }

    def test_json_report_is_structured_source_free_and_marks_ai_as_advisory(self):
        self.review["static_analysis"][0]["message"] = (
            "SENSITIVE_SOURCE_SENTINEL"
        )
        report = build_report_payload([self.review])
        encoded = json_report_bytes(report)
        decoded = json.loads(encoded)

        self.assertEqual(decoded["version"], "0.3.0")
        self.assertEqual(decoded["files"][0]["filename"], "src/module.py")
        self.assertEqual(
            decoded["files"][0]["confirmed_findings"][0]["source"],
            "Confirmed static",
        )
        self.assertEqual(
            decoded["files"][0]["ai_suggestions"][0]["source"],
            "AI suggestion",
        )
        self.assertNotIn(b"SENSITIVE_SOURCE_SENTINEL", encoded)
        self.assertNotIn(b"source code", encoded.lower())

    def test_pdf_report_has_valid_structure_and_separates_finding_sources(self):
        report = build_report_payload([self.review])
        pdf = pdf_report_bytes(report)

        self.assertTrue(pdf.startswith(b"%PDF-1.4"))
        self.assertTrue(pdf.rstrip().endswith(b"%%EOF"))
        self.assertIn(b"Confirmed static finding", pdf)
        self.assertIn(b"AI-generated suggestions", pdf)
        self.assertIn(b"Optional optimization", pdf)
        xref_offset = int(pdf.rsplit(b"startxref\n", 1)[1].splitlines()[0])
        self.assertEqual(pdf[xref_offset:xref_offset + 4], b"xref")
        self.assertEqual(pdf.count(b"/Type /Page "), 1)

    def test_pull_request_report_includes_project_summary_and_metadata(self):
        report = build_pull_request_report_payload(
            [self.review],
            {
                "repository": "octocat/sample",
                "number": 7,
                "title": "Review changes",
                "author": "octocat",
                "base_branch": "main",
                "head_branch": "feature",
                "base_sha": "a" * 40,
                "head_sha": "b" * 40,
                "url": "https://github.com/octocat/sample/pull/7",
                "body": "PR description.",
            },
            "Reviewed 1 of 1 changed files.",
            1,
            1,
            "Completed",
            {"Security": 1},
            {"confirmed_static": {"High": 1}},
        )

        decoded = json.loads(json_report_bytes(report))
        pdf = pdf_report_bytes(report)
        self.assertEqual(decoded["pull_request"]["number"], 7)
        self.assertEqual(decoded["executive_summary"], "Reviewed 1 of 1 changed files.")
        self.assertIn(b"Pull request executive summary", pdf)
        self.assertIn(b"octocat/sample #7", pdf)
        self.assertIn(b"Confirmed findings by category: Security: 1", pdf)


if __name__ == "__main__":
    unittest.main()
