
import unittest

from core.bug_detector import detect_bugs


class TestBugDetector(unittest.TestCase):

    def test_division_by_zero(self):
        findings = detect_bugs("result = 10 / 0")

        self.assertEqual(len(findings), 1)
        self.assertEqual(findings[0]["issue"], "Division by zero")
        self.assertEqual(findings[0]["severity"], "High")

    def test_normal_division(self):
        findings = detect_bugs("result = 10 / 2")

        self.assertEqual(findings, [])

    def test_broad_exception(self):
        code = """
try:
    print("Hello")
except Exception:
    pass
"""
        findings = detect_bugs(code)

        self.assertTrue(
            any(
                item["issue"] == "Broad exception handling"
                for item in findings
            )
        )

    def test_syntax_error(self):
        findings = detect_bugs("if True print('Hello')")

        self.assertEqual(findings[0]["issue"], "Syntax error")

    def test_empty_input(self):
        findings = detect_bugs("")

        self.assertEqual(findings[0]["issue"], "Invalid input")


if __name__ == "__main__":
    unittest.main()
