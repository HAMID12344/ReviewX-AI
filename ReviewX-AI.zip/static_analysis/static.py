
from static_analysis.analyzer import analyze_code

SAMPLE_CODE = """
import os

def divide(a, b):
    password = "admin123"
    return a / b

print(divide(10, 0))
"""


def main() -> None:
    print("=" * 60)
    print("       REVIEWX AI - STATIC ANALYSIS ENGINE")
    print("=" * 60)

    results = analyze_code(SAMPLE_CODE)
    for result in results:
        print("\nTool:", result["tool"])
        print("Status:", result["status"])
        print("Message:")
        print(result["message"])
        print("-" * 60)


if __name__ == "__main__":
    main()
