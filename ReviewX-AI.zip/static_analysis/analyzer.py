
import ast
import importlib.util
import json
import re
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Literal, TypedDict

ToolStatus = Literal["Passed", "Issues Found", "Error"]


class AnalysisResult(TypedDict):
    tool: str
    status: ToolStatus
    message: str
    exit_code: int | None


ALLOWED_TOOLS: dict[str, tuple[str, ...]] = {
    "ruff": ("check", "--output-format=json"),
    "bandit": ("-f", "json"),
    "mypy": ("--show-error-codes", "--no-incremental"),
}

MAX_CODE_SIZE_BYTES = 102_400
MAX_OUTPUT_CHARS = 12000
TIMEOUT_SECONDS = 30


def _result(
    tool: str,
    status: ToolStatus,
    message: str,
    exit_code: int | None = None,
) -> AnalysisResult:
    return {
        "tool": tool,
        "status": status,
        "message": message,
        "exit_code": exit_code,
    }


def _validate_source(code: object, max_size_bytes: int) -> str | None:
    if not isinstance(code, str) or not code.strip():
        return "Please provide valid, non-empty Python code."

    if max_size_bytes <= 0:
        return "The maximum source size must be a positive number of bytes."

    try:
        source_size = len(code.encode("utf-8"))
    except UnicodeEncodeError:
        return "The source must be valid UTF-8 text."

    if source_size > max_size_bytes:
        return f"Source exceeds the {max_size_bytes}-byte size limit."

    return None


def check_syntax(code: str) -> AnalysisResult:
    """Check Python syntax using AST."""
    try:
        ast.parse(code)
        return _result(
            "Python AST",
            "Passed",
            "No syntax errors detected.",
        )
    except SyntaxError as error:
        return _result(
            "Python AST",
            "Issues Found",
            f"Line {error.lineno or 1}: {error.msg}",
        )
    except (ValueError, RecursionError):
        return _result(
            "Python AST",
            "Issues Found",
            "The source could not be parsed as valid Python.",
        )


def _tool_reported_findings(tool: str, output: str) -> bool:
    if tool == "mypy":
        return re.search(r":\s*error:", output) is not None

    try:
        report = json.loads(output)
    except json.JSONDecodeError:
        return False

    if tool == "ruff":
        return isinstance(report, list) and bool(report)

    if tool == "bandit" and isinstance(report, dict):
        return not report.get("errors") and bool(report.get("results"))

    return False


def run_tool(tool: str, code: str) -> AnalysisResult:
    """Run one allowlisted static analysis tool without executing the source."""
    if tool not in ALLOWED_TOOLS:
        return _result(tool, "Error", "Tool is not allowed.")

    try:
        validation_error = _validate_source(code, MAX_CODE_SIZE_BYTES)
        if validation_error is not None:
            return _result(tool, "Error", validation_error)

        if importlib.util.find_spec(tool) is None:
            return _result(
                tool,
                "Error",
                f"The {tool} package is not installed in this Python environment.",
            )

        with tempfile.TemporaryDirectory(prefix="reviewx-") as temp_dir:
            source_path = Path(temp_dir) / "submitted.py"
            source_path.write_text(code, encoding="utf-8")
            command = [
                sys.executable,
                "-m",
                tool,
                *ALLOWED_TOOLS[tool],
                str(source_path),
            ]
            result = subprocess.run(
                command,
                capture_output=True,
                text=True,
                timeout=TIMEOUT_SECONDS,
                check=False,
                shell=False,
                cwd=temp_dir,
            )

        combined_output = "\n".join(
            text.strip()
            for text in (result.stdout, result.stderr)
            if text and text.strip()
        )
        report_output = (
            result.stdout
            if tool in {"ruff", "bandit"}
            else combined_output
        )
        output = combined_output
        if len(output) > MAX_OUTPUT_CHARS:
            output = output[:MAX_OUTPUT_CHARS] + "\n[Output truncated]"

        if result.returncode == 0:
            return _result(
                tool,
                "Passed",
                output or "No issues reported.",
                result.returncode,
            )

        if result.returncode == 1 and _tool_reported_findings(
            tool,
            report_output,
        ):
            return _result(
                tool,
                "Issues Found",
                output or "The tool reported issues.",
                result.returncode,
            )

        return _result(
            tool,
            "Error",
            output or f"Tool exited with code {result.returncode}.",
            result.returncode,
        )
    except subprocess.TimeoutExpired:
        return _result(
            tool,
            "Error",
            f"Analysis timed out after {TIMEOUT_SECONDS} seconds.",
        )
    except (OSError, UnicodeError, subprocess.SubprocessError) as error:
        return _result(
            tool,
            "Error",
            f"Could not run the {tool} analyzer: {error}",
        )


def analyze_code(
    code: str,
    max_size_bytes: int = MAX_CODE_SIZE_BYTES,
) -> list[AnalysisResult]:
    """Run all static analysis checks."""
    validation_error = _validate_source(code, max_size_bytes)
    if validation_error is not None:
        return [_result("Input Validation", "Error", validation_error)]

    syntax_result = check_syntax(code)
    results = [syntax_result]
    if syntax_result["status"] != "Passed":
        return results

    results.extend(run_tool(tool, code) for tool in ALLOWED_TOOLS)
    return results
