from collections import defaultdict
from dataclasses import asdict

import streamlit as st

from core import __version__
from core.findings import ConfirmedFinding, FileReview
from core.uploads import (
    UploadValidationError,
    extract_python_files,
    read_python_upload,
)
from integrations.github_client import (
    GitHubAPIError,
    GitHubInputError,
    GitHubRepository,
    PullRequestMetadata,
    get_github_client,
    parse_repository_identifier,
)
from integrations.github_comments import (
    ReviewApprovalRequired,
    ReviewComment,
    preview_review_comments,
    publish_approved_review,
)
from integrations.github_review import (
    PullRequestReview,
    analyze_pull_request,
)
from reports.export import (
    build_pull_request_report_payload,
    build_report_payload,
    json_report_bytes,
    pdf_report_bytes,
)
from reviewer import review_sources

REVIEW_STATE_KEY = "reviewx_file_reviews"


def _show_file_review(result: FileReview) -> None:
    st.subheader("File review")
    st.text(result["filename"])
    st.write(f"AI review status: {result['ai_review_status']}")
    if result["ai_review_error"]:
        st.warning(result["ai_review_error"])

    st.markdown("**Static analyzer results**")
    for item in result["static_analysis"]:
        with st.expander(f"{item['tool']}: {item['status']}"):
            st.code(item["message"], language="text")

    st.markdown("**Confirmed static findings**")
    if result["confirmed_findings"]:
        grouped: dict[str, list[ConfirmedFinding]] = defaultdict(list)
        for finding in result["confirmed_findings"]:
            grouped[finding["category"]].append(finding)
        for category, findings in sorted(grouped.items()):
            st.write(category)
            for finding in findings:
                st.write(
                    f"Line {finding['line']} | {finding['severity']} | "
                    f"{finding['issue']}"
                )
                st.caption(finding["explanation"])
    else:
        st.write("No confirmed static findings.")

    st.markdown("**AI-generated suggestions (unconfirmed)**")
    if result["ai_summary"]:
        st.write(result["ai_summary"])
    if result["ai_suggestions"]:
        for suggestion in result["ai_suggestions"]:
            st.write(
                f"Line {suggestion['line']} | {suggestion['severity']} | "
                f"{suggestion['category']} | {suggestion['issue']}"
            )
            st.write(suggestion["explanation"])
            st.caption(f"Recommendation: {suggestion['recommendation']}")
    elif result["ai_review_status"] == "Completed":
        st.write("No validated AI suggestions.")


def _render_downloads(file_reviews: list[FileReview]) -> None:
    report = build_report_payload(file_reviews)
    col_json, col_pdf = st.columns(2)
    with col_json:
        st.download_button(
            "Download JSON report",
            data=json_report_bytes(report),
            file_name="reviewx_report.json",
            mime="application/json",
        )
    with col_pdf:
        st.download_button(
            "Download PDF report",
            data=pdf_report_bytes(report),
            file_name="reviewx_report.pdf",
            mime="application/pdf",
        )


def _show_pull_request_review(
    review: PullRequestReview,
    comments: list[ReviewComment],
) -> None:
    pull_request = review["pull_request"]
    st.subheader("Pull Request review")
    st.text(
        f"{review['repository']} #{pull_request.number}: {pull_request.title}"
    )
    st.write(f"Review status: {review['review_status']}")
    st.write(review["executive_summary"])
    st.text(
        f"Author: {pull_request.author} | "
        f"{pull_request.base_branch} <- {pull_request.head_branch}"
    )
    if pull_request.body:
        with st.expander("Pull request description"):
            st.text(pull_request.body)
            st.markdown("**Confirmed findings by category**")
            st.json(review["category_breakdown"])
    st.markdown("**Severity breakdown**")
    st.json(review["severity_breakdown"])
    st.write(
        f"Changed files: {review['changed_file_count']} | "
        f"Reviewed files: {review['reviewed_file_count']}"
    )
    for file_review in review["files"]:
        with st.expander("File details"):
            st.text(file_review["filename"])
            if file_review["review"] is None:
                st.warning(file_review["skip_reason"] or "File was not reviewed.")
            else:
                _show_file_review(file_review["review"])
            if not file_review["diff_complete"]:
                st.caption(
                    "Inline comments are disabled because a complete diff "
                    "for this file was not available."
                )

    st.markdown("**Review comments preview**")
    if comments:
        for comment in comments:
            st.text(
                f"{comment['path']}:{comment['line']} "
                f"({comment['source']})\n{comment['body']}"
            )
    else:
        st.info(
            "No validated inline comments are available for lines in the PR diff."
        )

    file_reviews = [
        item["review"]
        for item in review["files"]
        if item["review"] is not None
    ]
    metadata = asdict(pull_request)
    metadata["repository"] = review["repository"]
    metadata["review_status"] = review["review_status"]
    metadata["changed_file_count"] = review["changed_file_count"]
    metadata["reviewed_file_count"] = review["reviewed_file_count"]
    report = build_pull_request_report_payload(
        file_reviews,
        metadata,
        review["executive_summary"],
        review["changed_file_count"],
        review["reviewed_file_count"],
        review["review_status"],
        review["category_breakdown"],
        review["severity_breakdown"],
    )
    col_json, col_pdf = st.columns(2)
    with col_json:
        st.download_button(
            "Download PR JSON report",
            data=json_report_bytes(report),
            file_name=f"reviewx_pr_{pull_request.number}.json",
            mime="application/json",
            key=f"github_json_{pull_request.number}",
        )
    with col_pdf:
        st.download_button(
            "Download PR PDF report",
            data=pdf_report_bytes(report),
            file_name=f"reviewx_pr_{pull_request.number}.pdf",
            mime="application/pdf",
            key=f"github_pdf_{pull_request.number}",
        )

    approval_key = (
        f"github_approval_{review['repository']}_"
        f"{pull_request.number}_{pull_request.head_sha}"
    )
    approved = st.checkbox(
        "I reviewed the preview and explicitly approve publishing this review.",
        key=approval_key,
    )
    if st.button(
        "Publish approved review to GitHub",
        disabled=not approved,
        key=f"github_publish_{pull_request.number}",
    ):
        try:
            with get_github_client() as client:
                published = publish_approved_review(
                    client,
                    review,
                    review["executive_summary"],
                    comments,
                    approved=True,
                )
            st.success(
                f"Review published as GitHub review #{published.get('id', 'unknown')}."
            )
        except (GitHubAPIError, GitHubInputError, ReviewApprovalRequired) as error:
            st.error(str(error))


def _render_github_review_mode() -> None:
    st.header("GitHub Pull Request Review")
    st.caption(
        "Repository source is fetched from GitHub and analyzed without execution. "
        "Comments are previewed and require explicit approval before publishing."
    )
    repository_input = st.text_input(
        "GitHub repository URL or owner/repository",
        key="reviewx_github_repository_input",
        placeholder="owner/repository",
    )

    if st.button("Connect to GitHub and load repositories"):
        try:
            with get_github_client() as client:
                login = client.authenticate()
                loaded_repositories = client.list_repositories()
            st.session_state["reviewx_github_login"] = login
            st.session_state["reviewx_github_repositories"] = loaded_repositories
            st.success(f"Connected to GitHub as {login}.")
        except (GitHubAPIError, GitHubInputError) as error:
            st.error(str(error))

    cached_repositories: list[GitHubRepository] = st.session_state.get(
        "reviewx_github_repositories",
        [],
    )
    selected_repository = ""
    if cached_repositories:
        selected_repository = st.selectbox(
            "Accessible repositories",
            options=[""] + [item.full_name for item in cached_repositories],
            key="reviewx_github_repository_selection",
        )

    if st.button("Load open pull requests"):
        try:
            owner, repository = parse_repository_identifier(
                repository_input.strip() or selected_repository
            )
            with get_github_client() as client:
                loaded_pull_requests = client.list_pull_requests(owner, repository)
            st.session_state["reviewx_github_selected_repo"] = (
                f"{owner}/{repository}"
            )
            st.session_state["reviewx_github_pull_requests"] = loaded_pull_requests
            st.session_state.pop("reviewx_github_pr_review", None)
            st.session_state.pop("reviewx_github_pr_comments", None)
            if not loaded_pull_requests:
                st.info("No open pull requests were found.")
        except (GitHubAPIError, GitHubInputError) as error:
            st.error(str(error))

    cached_pull_requests: list[PullRequestMetadata] = st.session_state.get(
        "reviewx_github_pull_requests",
        [],
    )
    if not cached_pull_requests:
        return

    selected_pull_request = st.selectbox(
        "Open pull request",
        options=cached_pull_requests,
        format_func=lambda item: f"#{item.number} {item.title}",
        key="reviewx_github_pull_request_selection",
    )
    allow_ai = st.checkbox(
        "I explicitly consent to sending this PR source code to Groq for AI review",
        value=False,
        key="reviewx_github_ai_consent",
    )
    if st.button(
        "Analyze Pull Request",
        key=f"github_analyze_{selected_pull_request.number}",
    ):
        progress = st.progress(0.0, text="Preparing pull request review...")

        def update_progress(stage: str, completed: int, total: int) -> None:
            ratio = completed / total if total else 1.0
            fraction = ratio * 0.5 + (0.0 if stage == "fetch" else 0.5)
            progress.progress(
                min(fraction, 1.0),
                text=f"{stage.title()} {completed} of {total} files",
            )

        try:
            owner, repository = parse_repository_identifier(
                st.session_state["reviewx_github_selected_repo"]
            )
            with get_github_client() as client:
                analyzed_pr = analyze_pull_request(
                    client,
                    owner,
                    repository,
                    selected_pull_request,
                    allow_ai=allow_ai,
                    on_progress=update_progress,
                )
            st.session_state["reviewx_github_pr_review"] = analyzed_pr
            st.session_state["reviewx_github_pr_comments"] = (
                preview_review_comments(analyzed_pr)
            )
            st.session_state[
                f"github_approval_{analyzed_pr['repository']}_"
                f"{selected_pull_request.number}_{selected_pull_request.head_sha}"
            ] = False
        except (GitHubAPIError, GitHubInputError) as error:
            st.error(str(error))
        finally:
            progress.empty()

    stored_review: PullRequestReview | None = st.session_state.get(
        "reviewx_github_pr_review"
    )
    if stored_review is not None:
        comments: list[ReviewComment] = st.session_state.get(
            "reviewx_github_pr_comments",
            [],
        )
        _show_pull_request_review(stored_review, comments)


def main() -> None:
    st.set_page_config(page_title=f"ReviewX AI v{__version__}")
    st.title("ReviewX AI")
    st.caption(f"Version {__version__}")
    st.write("Review Python code with local static analysis and AST checks.")
    st.info(
        "Uploaded code is analyzed without execution. If AI review is enabled "
        "and you explicitly consent, each source file is sent to Groq."
    )

    input_mode = st.radio(
        "Choose source",
        (
            "Paste code",
            "Upload Python file",
            "Upload ZIP project",
            "GitHub Pull Request Review",
        ),
        horizontal=True,
    )

    if input_mode == "GitHub Pull Request Review":
        _render_github_review_mode()
        return

    with st.form("review_form"):
        uploaded_file = None
        if input_mode == "Paste code":
            pasted_source = st.text_area(
                "Python source code",
                height=320,
                placeholder="Paste Python code to review...",
            )
        elif input_mode == "Upload Python file":
            uploaded_file = st.file_uploader(
                "Choose one Python file",
                type=["py"],
                accept_multiple_files=False,
                max_upload_size=1,
            )
            pasted_source = ""
        else:
            uploaded_file = st.file_uploader(
                "Choose a ZIP project",
                type=["zip"],
                accept_multiple_files=False,
                max_upload_size=10,
            )
            pasted_source = ""

        allow_ai = st.checkbox(
            "I explicitly consent to sending this source code to Groq for AI review",
            value=False,
        )
        submitted = st.form_submit_button("Review source")

    if submitted:
        st.session_state[REVIEW_STATE_KEY] = []
        try:
            if input_mode == "Paste code":
                sources = {"pasted_code.py": pasted_source}
            elif uploaded_file is None:
                st.warning("Choose a file before starting the review.")
                sources = {}
            elif input_mode == "Upload Python file":
                filename = uploaded_file.name.replace("\\", "/").rsplit("/", 1)[-1]
                source = read_python_upload(filename, uploaded_file.getvalue())
                sources = {filename: source}
            else:
                sources = extract_python_files(uploaded_file.getvalue())
        except UploadValidationError as error:
            st.error(str(error))
            sources = {}

        if sources:
            if input_mode == "Upload ZIP project":
                st.write(f"Found {len(sources)} eligible Python files.")
            progress = st.progress(0, text="Preparing file reviews...")

            def update_progress(completed: int, total: int) -> None:
                progress.progress(
                    completed / total,
                    text=f"Reviewed {completed} of {total} files",
                )

            results: list[FileReview] = review_sources(
                sources,
                allow_ai=allow_ai,
                on_progress=update_progress,
            )
            progress.empty()
            st.session_state[REVIEW_STATE_KEY] = results

    file_reviews = st.session_state.get(REVIEW_STATE_KEY, [])
    if file_reviews:
        st.header("Review results")
        for result in file_reviews:
            _show_file_review(result)
        _render_downloads(file_reviews)


if __name__ == "__main__":
    main()
