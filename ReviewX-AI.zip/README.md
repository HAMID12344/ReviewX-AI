# ReviewX AI v0.3

ReviewX AI is a Streamlit-based Python code review tool. It combines local
Python AST checks with Ruff, Bandit, and Mypy, and can request advisory
suggestions from Groq when AI review is enabled and the user explicitly
consents.

## Features

- Review pasted Python, one uploaded `.py` file, or Python files in a ZIP.
- Analyze every eligible ZIP member independently.
- Review accessible GitHub pull requests and inspect changed Python files.
- Inspect confirmed AST/static-tool findings separately from unconfirmed,
source-validated AI suggestions.
- Download source-free JSON and PDF reports.
- Preview diff-validated GitHub review comments before explicitly approving
  publication.
- Uploaded code is analyzed, never executed.

## Architecture

```mermaid
flowchart TD
    UI[Streamlit app]
    UI --> Uploads[core/uploads.py]
    Uploads --> Review[reviewer.py]
    UI --> GHClient[integrations/github_client.py]
    GHClient --> GH[GitHub REST API]
    GHClient --> GHReview[integrations/github_review.py]
    GHReview --> Review
    Review --> AST[AST bug detector]
    Review --> Static[Ruff / Bandit / Mypy]
    Review --> Groq[Optional Groq review]
    AST --> Findings[Validated findings]
    Static --> Findings
    Groq --> Findings
    Findings --> Reports[reports/export.py]
    Findings --> Preview[integrations/github_comments.py]
    Preview --> Approval[Explicit user approval]
    Approval --> GHClient
```

GitHub access, PR analysis, and comment publication are isolated under
`integrations/`. The existing upload flow continues to use `core/uploads.py`
and `reviewer.py`. PR source is fetched through the fixed GitHub API host,
analyzed without execution, and associated with the PR head commit and file
path. Inline comments are limited to complete, parsed diff lines.

## Requirements and setup

Python 3.14 is supported. From PowerShell in the project directory:

```powershell
.\venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
```

The existing virtual environment can be reused. For a new environment, create
one with `python -m venv venv` before activating it.

Copy `.env.example` to `.env` and set `GROQ_API_KEY` locally if you want to use
AI review. Keep `.env` private; it is excluded by `.gitignore`. AI review is
disabled by default and requires both `ENABLE_AI_REVIEW=true` in `.env` and
explicit consent in the dashboard. Without that consent, source remains on the
local analysis path.

The GitHub client reads `GITHUB_TOKEN` from the process environment or the
project `.env` file. `.env.example` contains placeholders only; do not commit a
real token. GitHub API access is read-only during repository discovery and PR
analysis. Publishing comments requires a separate explicit confirmation in
the app.

## Start the dashboard

```powershell
.\venv\Scripts\Activate.ps1
streamlit run app.py
```

Select paste, single-file, or ZIP input. For ZIP reviews, non-Python files are
ignored. Files are read in memory; no archive paths are written to disk. The
dashboard rejects unsafe paths, symlinks, duplicate paths, encrypted entries,
invalid UTF-8, and archives or source files beyond configured limits.

Current upload limits:

- Individual Python source: 100 KiB.
- ZIP upload: 10 MiB compressed; 50 MiB total declared uncompressed size.
- ZIP members: 500 maximum; Python source files: 25 maximum.

These are defensive application limits, not guarantees against every possible
malformed archive or static-analysis resource exhaustion.

## GitHub Pull Request review

Create a fine-grained GitHub Personal Access Token restricted to the
repositories ReviewX AI should access. Grant only:

- **Metadata: read-only**
- **Contents: read-only**
- **Pull requests: read and write** (write is needed only to publish a review)

Set `GITHUB_TOKEN` in the process environment or add it locally to `.env`. The
token is never displayed in the dashboard or included in API error messages.
The app can list repositories accessible to the token, or accept a GitHub
repository URL or `owner/repository`, then list open pull requests.

Select a PR and choose **Analyze Pull Request**. ReviewX fetches changed file
metadata, patches, and source from the PR head commit. It reviews eligible
Python files through the existing review engine; deleted, unsupported, unsafe,
oversized, and unreadable files are skipped with a reason. Missing or
incomplete patches can still be analyzed, but cannot produce inline comments.
Reports include PR metadata, per-file results, and a PR-level summary.

Inline comments are generated only for validated finding lines found on the
right side of a complete PR diff. Inspect the preview, check the explicit
approval box, and select **Publish approved review to GitHub** to post a
`COMMENT` review. No comments are posted automatically. Tests use mocked
responses and do not contact GitHub or publish reviews.

The GitHub client uses HTTPS, bounded response bodies, request timeouts,
bounded pagination, and fixed API endpoints; it does not fetch arbitrary URLs
from repository content. PR analysis is limited to 100 changed files, and
individual source files use the existing 100 KiB source limit. The current
prototype targets `api.github.com`; GitHub Enterprise is not supported.

## Reports

After review, use the JSON or PDF download button. Reports include filenames,
tool statuses, normalized confirmed findings, AI review status, and validated
AI suggestions. They do not include the full uploaded source or raw analyzer
output. AI suggestions are advisory and remain clearly distinguished from
static-tool findings.

## Run offline checks

```powershell
python -m unittest discover -s tests -v
python -m ruff check .
python -m bandit -r core static_analysis
python -m mypy core static_analysis reviewer.py reports
python -m mypy --follow-imports=skip app.py
```

The unit tests do not make live Groq API requests. Static-analysis subprocesses
inspect temporary source files and are configured with timeouts; they do not
execute the submitted program.

## Limitations

- AI output is constrained to structured suggestions with source-line evidence
  and is filtered against confirmed finding lines. Semantic validation cannot
  prove every remaining AI suggestion is correct or non-contradictory.
- PR files are analyzed independently and sequentially; ReviewX does not yet
  perform cross-file semantic analysis. Comments are disabled for files whose
  diff is missing or incomplete.
- The unused-variable guard rejects AI unused-variable claims when a matching
  assigned name has a later AST load. Scope-sensitive and dynamic Python
  behavior cannot be completely inferred statically.
- Large ZIP projects beyond the limits are rejected rather than partially
  reviewed. Files are analyzed sequentially, so many static checks may take
  time.
- Groq availability, model behavior, credentials, and network conditions are
  external dependencies. A clean static scan does not prove code is safe.
- This release is not a LangGraph multi-agent system and does not execute or
  sandbox submitted code because it does not run it at all.
