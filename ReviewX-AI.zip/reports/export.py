import json
import textwrap
from collections.abc import Mapping, Sequence
from datetime import UTC, datetime
from typing import NotRequired, TypedDict

from core import __version__
from core.findings import FileReview


class ReportTool(TypedDict):
    tool: str
    status: str
    exit_code: int | None


class ReportFile(TypedDict):
    filename: str
    ai_review_status: str
    ai_review_error: str | None
    summary: str | None
    static_analysis: list[ReportTool]
    confirmed_findings: list[dict[str, object]]
    ai_suggestions: list[dict[str, object]]


class ProjectReport(TypedDict):
    version: str
    generated_at: str
    files: list[ReportFile]
    executive_summary: NotRequired[str]
    pull_request: NotRequired[dict[str, object]]
    changed_file_count: NotRequired[int]
    reviewed_file_count: NotRequired[int]
    review_status: NotRequired[str]
    category_breakdown: NotRequired[dict[str, int]]
    severity_breakdown: NotRequired[dict[str, dict[str, int]]]


def build_report_payload(file_reviews: Sequence[FileReview]) -> ProjectReport:
    """Build a source-free report suitable for download and sharing."""
    report_files: list[ReportFile] = []
    for file_review in file_reviews:
        report_files.append(
            {
                "filename": file_review["filename"],
                "ai_review_status": file_review["ai_review_status"],
                "ai_review_error": file_review["ai_review_error"],
                "summary": file_review["ai_summary"],
                "static_analysis": [
                    {
                        "tool": item["tool"],
                        "status": item["status"],
                        "exit_code": item["exit_code"],
                    }
                    for item in file_review["static_analysis"]
                ],
                "confirmed_findings": [
                    dict(item) for item in file_review["confirmed_findings"]
                ],
                "ai_suggestions": [
                    dict(item) for item in file_review["ai_suggestions"]
                ],
            }
        )
    return {
        "version": __version__,
        "generated_at": datetime.now(UTC).isoformat(timespec="seconds"),
        "files": report_files,
    }


def build_pull_request_report_payload(
    file_reviews: Sequence[FileReview],
    pull_request: Mapping[str, object],
    executive_summary: str,
    changed_file_count: int,
    reviewed_file_count: int,
    review_status: str,
    category_breakdown: Mapping[str, int],
    severity_breakdown: Mapping[str, Mapping[str, int]],
) -> ProjectReport:
    """Include PR-level metadata and summary without changing upload reports."""
    report = build_report_payload(file_reviews)
    report["pull_request"] = dict(pull_request)
    report["executive_summary"] = executive_summary
    report["changed_file_count"] = changed_file_count
    report["reviewed_file_count"] = reviewed_file_count
    report["review_status"] = review_status
    report["category_breakdown"] = dict(category_breakdown)
    report["severity_breakdown"] = {
        group: dict(counts)
        for group, counts in severity_breakdown.items()
    }
    return report


def json_report_bytes(report: ProjectReport) -> bytes:
    return json.dumps(
        report,
        ensure_ascii=False,
        indent=2,
    ).encode("utf-8")


def _text(value: object, fallback: str = "") -> str:
    return value if isinstance(value, str) else fallback


def _finding_lines(
    finding: Mapping[str, object],
    ai_suggestion: bool,
) -> list[tuple[str, str]]:
    prefix = "AI suggestion" if ai_suggestion else "Confirmed static finding"
    line = finding.get("line")
    severity = _text(finding.get("severity"), "Unknown")
    category = _text(finding.get("category"), "Other")
    issue = _text(finding.get("issue"), "Finding")
    details = _text(finding.get("recommendation" if ai_suggestion else "explanation"))
    lines = [
        ("body", f"{prefix} | Line {line} | {severity} | {category}: {issue}")
    ]
    if details:
        lines.append(("body", details))
    return lines


def _report_blocks(report: ProjectReport) -> list[tuple[str, str]]:
    blocks: list[tuple[str, str]] = [
        ("title", "ReviewX AI - Code Review Report"),
        ("body", f"Version {report['version']} | Generated {report['generated_at']}"),
        ("body", "Static findings are tool-generated results; AI suggestions are unconfirmed."),
        ("spacer", ""),
    ]
    summary = report.get("executive_summary")
    if summary:
        blocks.extend(
            [
                ("heading", "Pull request executive summary"),
                ("body", summary),
            ]
        )
    pull_request = report.get("pull_request")
    if pull_request is not None:
        metadata_lines = [
            ("heading", "Pull request details"),
            (
                "body",
                (
                    f"{pull_request.get('repository', 'Repository')} "
                    f"#{pull_request.get('number', '')}: "
                    f"{pull_request.get('title', '')}"
                ),
            ),
        ]
        for label, key in (
            ("Author", "author"),
            ("Base branch", "base_branch"),
            ("Head branch", "head_branch"),
            ("Pull request URL", "url"),
            ("Review status", "review_status"),
            ("Changed files", "changed_file_count"),
            ("Reviewed files", "reviewed_file_count"),
        ):
            value = pull_request.get(key)
            if value is not None:
                metadata_lines.append(("body", f"{label}: {value}"))
        description = pull_request.get("body")
        if isinstance(description, str) and description:
            metadata_lines.append(("body", f"Description: {description}"))
        severity_breakdown = report.get("severity_breakdown")
        category_breakdown = report.get("category_breakdown")
        if category_breakdown is not None:
            category_text = ", ".join(
                f"{category}: {count}"
                for category, count in sorted(category_breakdown.items())
            )
            metadata_lines.append(
                ("body", f"Confirmed findings by category: {category_text}")
            )
        if severity_breakdown is not None:
            for group, counts in sorted(severity_breakdown.items()):
                count_text = ", ".join(
                    f"{severity}: {count}"
                    for severity, count in sorted(counts.items())
                )
                metadata_lines.append(
                    ("body", f"{group.replace('_', ' ').title()}: {count_text}")
                )
        blocks.extend(metadata_lines)
        blocks.append(("spacer", ""))

    for file_review in report["files"]:
        blocks.extend(
            [
                ("heading", f"File: {file_review['filename']}"),
                ("body", f"AI review status: {file_review['ai_review_status']}"),
            ]
        )
        if file_review["ai_review_error"]:
            blocks.append(("body", f"AI review note: {file_review['ai_review_error']}"))
        if file_review["summary"]:
            blocks.append(("body", f"AI summary: {file_review['summary']}"))

        blocks.append(("subheading", "Static analyzer status"))
        if file_review["static_analysis"]:
            for tool in file_review["static_analysis"]:
                blocks.append(
                    (
                        "body",
                        (
                            f"{tool['tool']}: {tool['status']} "
                            f"(exit code: {tool['exit_code']})"
                        ),
                    )
                )
        else:
            blocks.append(("body", "No static analyzer results."))

        blocks.append(("subheading", "Confirmed static findings"))
        if file_review["confirmed_findings"]:
            for finding in file_review["confirmed_findings"]:
                blocks.extend(_finding_lines(finding, False))
        else:
            blocks.append(("body", "No confirmed static findings."))

        blocks.append(("subheading", "AI-generated suggestions (unconfirmed)"))
        if file_review["ai_suggestions"]:
            for suggestion in file_review["ai_suggestions"]:
                blocks.extend(_finding_lines(suggestion, True))
        else:
            blocks.append(("body", "No validated AI suggestions."))
        blocks.append(("spacer", ""))
    return blocks


def _pdf_literal(text: str) -> str:
    encoded = text.encode("cp1252", errors="replace")
    escaped: list[str] = []
    for value in encoded:
        if value in (ord("("), ord(")"), ord("\\")):
            escaped.append("\\" + chr(value))
        elif value < 32 or value >= 127:
            escaped.append(f"\\{value:03o}")
        else:
            escaped.append(chr(value))
    return "".join(escaped)


def _content_stream(
    page_lines: list[tuple[str, str, int]],
    page_number: int,
    page_count: int,
) -> bytes:
    commands = [
        "BT /F2 8 Tf 54 758 Td (ReviewX AI | Code Review Report) Tj ET",
        "0.7 w 54 748 m 558 748 l S",
    ]
    for kind, text, y in page_lines:
        if kind == "title":
            font, size = "F2", 18
        elif kind == "heading":
            font, size = "F2", 13
        elif kind == "subheading":
            font, size = "F2", 10
        else:
            font, size = "F1", 9
        commands.append(
            f"BT /{font} {size} Tf 54 {y} Td ({_pdf_literal(text)}) Tj ET"
        )
    commands.extend(
        [
            "0.7 w 54 45 m 558 45 l S",
            f"BT /F1 8 Tf 54 30 Td (ReviewX AI | Version {__version__}) Tj ET",
            f"BT /F1 8 Tf 520 30 Td ({page_number} / {page_count}) Tj ET",
        ]
    )
    return "\n".join(commands).encode("ascii")


def pdf_report_bytes(report: ProjectReport) -> bytes:
    """Render a compact PDF without requiring an additional runtime package."""
    page_height = 792
    bottom = 60
    y = 720
    pages: list[list[tuple[str, str, int]]] = [[]]

    for kind, text in _report_blocks(report):
        if kind == "spacer":
            y -= 8
            continue
        width = 90 if kind == "body" else 72
        wrapped = textwrap.wrap(
            text,
            width=width,
            break_long_words=True,
            break_on_hyphens=False,
        ) or [""]
        leading = 23 if kind == "title" else 17 if kind == "heading" else 14
        if y - leading * len(wrapped) < bottom:
            pages.append([])
            y = 720
        for line in wrapped:
            pages[-1].append((kind, line, y))
            y -= leading
        y -= 5 if kind in {"heading", "subheading"} else 2

    objects: list[bytes | None] = [None] * 5
    objects[1] = b"<< /Type /Catalog /Pages 2 0 R >>"
    objects[3] = (
        b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica "
        b"/Encoding /WinAnsiEncoding >>"
    )
    objects[4] = (
        b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold "
        b"/Encoding /WinAnsiEncoding >>"
    )
    kids: list[str] = []
    for index, lines in enumerate(pages, start=1):
        page_object = len(objects)
        content_object = page_object + 1
        kids.append(f"{page_object} 0 R")
        stream = _content_stream(lines, index, len(pages))
        objects.append(
            (
                f"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 {page_height}] "
                f"/Resources << /Font << /F1 3 0 R /F2 4 0 R >> >> "
                f"/Contents {content_object} 0 R >>"
            ).encode("ascii")
        )
        objects.append(
            f"<< /Length {len(stream)} >>\nstream\n".encode("ascii")
            + stream
            + b"\nendstream"
        )
    objects[2] = (
        f"<< /Type /Pages /Kids [{' '.join(kids)}] /Count {len(pages)} >>"
    ).encode("ascii")

    pdf = bytearray(b"%PDF-1.4\n%\xe2\xe3\xcf\xd3\n")
    offsets = [0]
    for object_id in range(1, len(objects)):
        obj = objects[object_id]
        if obj is None:
            raise ValueError("PDF object table is incomplete.")
        offsets.append(len(pdf))
        pdf.extend(f"{object_id} 0 obj\n".encode("ascii"))
        pdf.extend(obj)
        pdf.extend(b"\nendobj\n")

    xref_offset = len(pdf)
    pdf.extend(f"xref\n0 {len(objects)}\n".encode("ascii"))
    pdf.extend(b"0000000000 65535 f \n")
    for offset in offsets[1:]:
        pdf.extend(f"{offset:010d} 00000 n \n".encode("ascii"))
    pdf.extend(
        (
            f"trailer\n<< /Size {len(objects)} /Root 1 0 R >>\n"
            f"startxref\n{xref_offset}\n%%EOF\n"
        ).encode("ascii")
    )
    return bytes(pdf)
