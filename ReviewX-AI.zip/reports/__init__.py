"""Report generation helpers for ReviewX AI."""
