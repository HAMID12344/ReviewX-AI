import re
from collections.abc import Callable
from typing import TypedDict

from core.findings import AISuggestion, ConfirmedFinding
from integrations.github_client import (
    ChangedFile,
    GitHubAPIError,
    GitHubClient,
    GitHubInputError,
    PullRequestMetadata,
    validate_repository,
)
from reviewer import ReviewResult, review_sources
from static_analysis.analyzer import MAX_CODE_SIZE_BYTES

MAX_PULL_REQUEST_FILES = 100
_HUNK_HEADER = re.compile(
    r"^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@(?: .*)?$"
)


class DiffLineMap(TypedDict):
    complete: bool
    right_lines: list[int]


class PullRequestFileReview(TypedDict):
    filename: str
    status: str
    previous_filename: str | None
    reviewed: bool
    skip_reason: str | None
    diff_complete: bool
    commentable_lines: list[int]
    review: ReviewResult | None


class PullRequestReview(TypedDict):
    repository: str
    pull_request: PullRequestMetadata
    executive_summary: str
    changed_file_count: int
    reviewed_file_count: int
    confirmed_findings_count: int
    ai_suggestions_count: int
    category_breakdown: dict[str, int]
    severity_breakdown: dict[str, dict[str, int]]
    review_status: str
    files: list[PullRequestFileReview]


ProgressCallback = Callable[[str, int, int], None]


def map_diff_lines(
    patch: str | None,
    additions: int,
    deletions: int,
) -> DiffLineMap:
    """Map new-side lines present in a complete patch; fail closed otherwise."""
    if not isinstance(patch, str) or not patch:
        return {"complete": False, "right_lines": []}

    right_lines: set[int] = set()
    total_additions = 0
    total_deletions = 0
    current_new_line = 0
    expected_old = 0
    expected_new = 0
    seen_old = 0
    seen_new = 0
    hunk_count = 0

    def finish_hunk() -> bool:
        return seen_old == expected_old and seen_new == expected_new

    for row in patch.splitlines():
        header = _HUNK_HEADER.match(row)
        if header is not None:
            if hunk_count and not finish_hunk():
                return {"complete": False, "right_lines": []}
            current_new_line = int(header.group(3))
            expected_old = int(header.group(2) or "1")
            expected_new = int(header.group(4) or "1")
            seen_old = 0
            seen_new = 0
            hunk_count += 1
            continue

        if not hunk_count:
            return {"complete": False, "right_lines": []}
        if row.startswith("+"):
            total_additions += 1
            seen_new += 1
            right_lines.add(current_new_line)
            current_new_line += 1
        elif row.startswith("-"):
            total_deletions += 1
            seen_old += 1
        elif row.startswith(" "):
            seen_old += 1
            seen_new += 1
            right_lines.add(current_new_line)
            current_new_line += 1
        elif row.startswith("\\"):
            continue
        else:
            return {"complete": False, "right_lines": []}

        if seen_old > expected_old or seen_new > expected_new:
            return {"complete": False, "right_lines": []}

    if (
        not hunk_count
        or not finish_hunk()
        or total_additions != additions
        or total_deletions != deletions
    ):
        return {"complete": False, "right_lines": []}
    return {"complete": True, "right_lines": sorted(right_lines)}


def _safe_changed_path(filename: str) -> bool:
    if (
        not isinstance(filename, str)
        or not filename
        or "\x00" in filename
        or "\\" in filename
    ):
        return False
    parts = filename.split("/")
    return (
        not filename.startswith("/")
        and all(part not in {"", ".", ".."} for part in parts)
        and filename.lower().endswith(".py")
    )


def _empty_file_review(
    changed_file: ChangedFile,
    diff_lines: DiffLineMap,
    reason: str,
) -> PullRequestFileReview:
    return {
        "filename": changed_file.filename,
        "status": changed_file.status,
        "previous_filename": changed_file.previous_filename,
        "reviewed": False,
        "skip_reason": reason,
        "diff_complete": diff_lines["complete"],
        "commentable_lines": diff_lines["right_lines"],
        "review": None,
    }


def analyze_pull_request(
    client: GitHubClient,
    owner: str,
    repository: str,
    pull_request: PullRequestMetadata,
    *,
    allow_ai: bool = False,
    on_progress: ProgressCallback | None = None,
) -> PullRequestReview:
    """Review eligible PR Python files with ReviewX's existing review engine."""
    owner, repository = validate_repository(owner, repository)
    changed_files = client.list_changed_files(
        owner,
        repository,
        pull_request.number,
    )
    if len(changed_files) > MAX_PULL_REQUEST_FILES:
        raise GitHubInputError(
            "The pull request exceeds the 100 changed-file analysis limit."
        )

    sources: dict[str, str] = {}
    file_reviews: list[PullRequestFileReview] = []
    diff_by_filename: dict[str, DiffLineMap] = {}
    stop_fetch_reason: str | None = None
    for index, changed_file in enumerate(changed_files, start=1):
        diff_lines = map_diff_lines(
            changed_file.patch,
            changed_file.additions,
            changed_file.deletions,
        )
        diff_by_filename[changed_file.filename] = diff_lines
        if changed_file.status == "removed":
            file_reviews.append(
                _empty_file_review(changed_file, diff_lines, "Deleted file.")
            )
        elif not _safe_changed_path(changed_file.filename):
            file_reviews.append(
                _empty_file_review(
                    changed_file,
                    diff_lines,
                    "Unsupported or unsafe file path; only Python files are reviewed.",
                )
            )
        elif changed_file.size is not None and changed_file.size > MAX_CODE_SIZE_BYTES:
            file_reviews.append(
                _empty_file_review(
                    changed_file,
                    diff_lines,
                    f"File exceeds the {MAX_CODE_SIZE_BYTES}-byte source limit.",
                )
            )
        elif stop_fetch_reason is not None:
            file_reviews.append(
                _empty_file_review(
                    changed_file,
                    diff_lines,
                    stop_fetch_reason,
                )
            )
        else:
            try:
                sources[changed_file.filename] = client.get_file_content(
                    owner,
                    repository,
                    changed_file.filename,
                    pull_request.head_sha,
                )
            except (GitHubAPIError, GitHubInputError) as error:
                file_reviews.append(
                    _empty_file_review(changed_file, diff_lines, str(error))
                )
                if isinstance(error, GitHubAPIError) and error.stop_fetching:
                    stop_fetch_reason = (
                        "Source retrieval stopped after a GitHub API error."
                    )
        if on_progress is not None:
            on_progress("fetch", index, len(changed_files))

    analyzed_by_name: dict[str, ReviewResult] = {}
    if sources:
        def report_analysis_progress(completed: int, total: int) -> None:
            if on_progress is not None:
                on_progress("analyze", completed, total)

        reviews = review_sources(
            sources,
            allow_ai=allow_ai,
            on_progress=report_analysis_progress,
        )
        analyzed_by_name = {
            result["filename"]: result
            for result in reviews
        }

    completed_files: list[PullRequestFileReview] = []
    for changed_file in changed_files:
        diff_lines = diff_by_filename[changed_file.filename]
        review = analyzed_by_name.get(changed_file.filename)
        if review is None:
            existing = next(
                (
                    item
                    for item in file_reviews
                    if item["filename"] == changed_file.filename
                ),
                None,
            )
            if existing is not None:
                completed_files.append(existing)
            else:
                completed_files.append(
                    _empty_file_review(
                        changed_file,
                        diff_lines,
                        "The file was not eligible for review.",
                    )
                )
        else:
            completed_files.append(
                {
                    "filename": changed_file.filename,
                    "status": changed_file.status,
                    "previous_filename": changed_file.previous_filename,
                    "reviewed": True,
                    "skip_reason": None,
                    "diff_complete": diff_lines["complete"],
                    "commentable_lines": diff_lines["right_lines"],
                    "review": review,
                }
            )

    confirmed_severities = {name: 0 for name in ("Critical", "High", "Medium", "Low", "Info")}
    ai_severities = {name: 0 for name in ("Critical", "High", "Medium", "Low", "Info")}
    confirmed_count = 0
    suggestion_count = 0
    reviewed_count = 0
    category_breakdown: dict[str, int] = {}
    for file_review in completed_files:
        review = file_review["review"]
        if review is None:
            continue
        reviewed_count += 1
        confirmed_count += len(review["confirmed_findings"])
        suggestion_count += len(review["ai_suggestions"])
        for finding in review["confirmed_findings"]:
            category_breakdown[finding["category"]] = (
                category_breakdown.get(finding["category"], 0) + 1
            )
            severity = finding["severity"]
            if severity in confirmed_severities:
                confirmed_severities[severity] += 1
        for suggestion in review["ai_suggestions"]:
            severity = suggestion["severity"]
            if severity in ai_severities:
                ai_severities[severity] += 1

    if not reviewed_count:
        status = "No eligible Python files"
    elif reviewed_count < len(changed_files):
        status = "Partial"
    else:
        status = "Completed"
    summary = (
        f"Reviewed {reviewed_count} of {len(changed_files)} changed files; "
        f"found {confirmed_count} confirmed static findings and "
        f"{suggestion_count} unconfirmed AI suggestions."
    )
    if not reviewed_count:
        summary = (
            "No changed Python files could be reviewed. "
            f"{len(changed_files)} files were changed."
        )

    return {
        "repository": f"{owner}/{repository}",
        "pull_request": pull_request,
        "executive_summary": summary,
        "changed_file_count": len(changed_files),
        "reviewed_file_count": reviewed_count,
        "confirmed_findings_count": confirmed_count,
        "ai_suggestions_count": suggestion_count,
        "category_breakdown": category_breakdown,
        "severity_breakdown": {
            "confirmed_static": confirmed_severities,
            "ai_suggestions": ai_severities,
        },
        "review_status": status,
        "files": completed_files,
    }


def review_file_findings(
    review: PullRequestReview,
) -> tuple[list[ConfirmedFinding], list[AISuggestion]]:
    confirmed: list[ConfirmedFinding] = []
    suggestions: list[AISuggestion] = []
    for file_review in review["files"]:
        result = file_review["review"]
        if result is None:
            continue
        confirmed.extend(result["confirmed_findings"])
        suggestions.extend(result["ai_suggestions"])
    return confirmed, suggestions
