from collections.abc import Mapping, Sequence
from typing import Literal, TypedDict

from integrations.github_client import GitHubClient, GitHubInputError
from integrations.github_review import PullRequestReview

CommentSource = Literal["Confirmed static", "AI suggestion"]


class ReviewComment(TypedDict):
    path: str
    line: int
    side: Literal["RIGHT"]
    body: str
    source: CommentSource


class ReviewApprovalRequired(PermissionError):
    """Raised when a user has not explicitly approved GitHub publication."""


def preview_review_comments(review: PullRequestReview) -> list[ReviewComment]:
    """Create previews only for validated finding lines present in the PR diff."""
    comments: list[ReviewComment] = []
    seen: set[tuple[str, int, str]] = set()
    for file_review in review["files"]:
        result = file_review["review"]
        if (
            result is None
            or not file_review["diff_complete"]
            or not file_review["commentable_lines"]
        ):
            continue
        allowed_lines = set(file_review["commentable_lines"])
        for finding in result["confirmed_findings"]:
            line = finding["line"]
            if line not in allowed_lines:
                continue
            body = (
                f"**Confirmed static finding - {finding['severity']} "
                f"{finding['category']}**\n\n{finding['issue']}\n\n"
                f"{finding['explanation']}"
            )
            key = (file_review["filename"], line, body)
            if key not in seen:
                seen.add(key)
                comments.append(
                    {
                        "path": file_review["filename"],
                        "line": line,
                        "side": "RIGHT",
                        "body": body,
                        "source": "Confirmed static",
                    }
                )
        for suggestion in result["ai_suggestions"]:
            line = suggestion["line"]
            if line not in allowed_lines:
                continue
            body = (
                f"**AI suggestion - unconfirmed ({suggestion['severity']}, "
                f"{suggestion['category']})**\n\n{suggestion['issue']}\n\n"
                f"{suggestion['explanation']}\n\n"
                f"Recommendation: {suggestion['recommendation']}"
            )
            key = (file_review["filename"], line, body)
            if key not in seen:
                seen.add(key)
                comments.append(
                    {
                        "path": file_review["filename"],
                        "line": line,
                        "side": "RIGHT",
                        "body": body,
                        "source": "AI suggestion",
                    }
                )
    return comments


def publish_approved_review(
    client: GitHubClient,
    review: PullRequestReview,
    summary: str,
    comments: Sequence[ReviewComment],
    *,
    approved: bool = False,
) -> Mapping[str, object]:
    """Publish a COMMENT review only after approval and diff-location checks."""
    if approved is not True:
        raise ReviewApprovalRequired(
            "Explicit user approval is required before publishing."
        )
    if not isinstance(summary, str) or len(summary) > 60_000:
        raise GitHubInputError("The pull request review summary is invalid.")

    allowed_lines = {
        file_review["filename"]: set(file_review["commentable_lines"])
        for file_review in review["files"]
        if file_review["diff_complete"]
    }
    api_comments: list[dict[str, str | int]] = []
    for comment in comments:
        if not isinstance(comment, Mapping):
            raise GitHubInputError("A review comment has an invalid format.")
        path = comment.get("path")
        line = comment.get("line")
        side = comment.get("side")
        body = comment.get("body")
        source = comment.get("source")
        if (
            not isinstance(path, str)
            or type(line) is not int
            or line < 1
            or path not in allowed_lines
            or line not in allowed_lines[path]
            or side != "RIGHT"
            or not isinstance(body, str)
            or not body.strip()
            or len(body) > 60_000
            or source not in {"Confirmed static", "AI suggestion"}
        ):
            raise GitHubInputError(
                "A review comment is not valid for the selected pull request diff."
            )
        api_comments.append(
            {
                "path": path,
                "line": line,
                "side": "RIGHT",
                "body": body,
            }
        )

    if len(api_comments) > 100:
        raise GitHubInputError(
            "A pull request review cannot contain more than 100 inline comments."
        )

    metadata = review["pull_request"]
    owner, repository = review["repository"].split("/", 1)
    return client.submit_review(
        owner,
        repository,
        metadata.number,
        metadata.head_sha,
        summary,
        api_comments,
        approved=True,
    )
