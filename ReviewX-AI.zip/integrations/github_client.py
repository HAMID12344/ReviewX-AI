import base64
import json
import os
import re
from dataclasses import dataclass
from pathlib import Path, PurePosixPath, PureWindowsPath
from typing import Any, Self
from urllib.parse import quote, urlsplit

import httpx
from dotenv import dotenv_values

from static_analysis.analyzer import MAX_CODE_SIZE_BYTES

GITHUB_API_URL = "https://api.github.com"
REQUEST_TIMEOUT_SECONDS = 15.0
MAX_RESPONSE_BYTES = 2 * 1024 * 1024
MAX_REQUEST_BYTES = 1024 * 1024
PAGE_SIZE = 100
MAX_REPOSITORY_PAGES = 10
MAX_PULL_REQUEST_PAGES = 10
MAX_CHANGED_FILE_PAGES = 30

_OWNER_PATTERN = re.compile(r"^[A-Za-z0-9](?:[A-Za-z0-9-]{0,37}[A-Za-z0-9])?$")
_REPOSITORY_PATTERN = re.compile(r"^[A-Za-z0-9_.-]{1,100}$")


class GitHubAPIError(RuntimeError):
    """A safe, user-facing GitHub API error without response or token data."""

    def __init__(
        self,
        message: str,
        status_code: int | None = None,
        *,
        stop_fetching: bool = False,
    ) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.stop_fetching = stop_fetching


class GitHubInputError(ValueError):
    """Invalid GitHub repository, pull request, or source path input."""


@dataclass(frozen=True)
class GitHubRepository:
    owner: str
    name: str
    full_name: str
    private: bool
    default_branch: str


@dataclass(frozen=True)
class PullRequestMetadata:
    number: int
    title: str
    body: str
    author: str
    base_branch: str
    head_branch: str
    base_sha: str
    head_sha: str
    url: str


@dataclass(frozen=True)
class ChangedFile:
    filename: str
    status: str
    additions: int
    deletions: int
    changes: int
    patch: str | None
    previous_filename: str | None
    sha: str | None
    size: int | None


def parse_repository_identifier(value: str) -> tuple[str, str]:
    """Accept only owner/repository or an HTTPS github.com repository URL."""
    if not isinstance(value, str) or not value.strip():
        raise GitHubInputError("Enter a GitHub repository URL or owner/repository.")

    candidate = value.strip()
    parsed = urlsplit(candidate)
    if parsed.scheme or parsed.netloc:
        if (
            parsed.scheme.lower() != "https"
            or parsed.netloc.lower() != "github.com"
            or parsed.username is not None
            or parsed.password is not None
            or parsed.query
            or parsed.fragment
        ):
            raise GitHubInputError(
                "Only HTTPS URLs hosted on github.com are supported."
            )
        parts = parsed.path.strip("/").split("/")
    else:
        parts = candidate.split("/")

    if len(parts) != 2:
        raise GitHubInputError("Use the form owner/repository.")

    owner, repository = parts
    if repository.lower().endswith(".git"):
        repository = repository[:-4]
    validate_repository(owner, repository)
    return owner, repository


def validate_repository(owner: str, repository: str) -> tuple[str, str]:
    if (
        not isinstance(owner, str)
        or not _OWNER_PATTERN.fullmatch(owner)
        or not isinstance(repository, str)
        or not _REPOSITORY_PATTERN.fullmatch(repository)
        or repository in {".", ".."}
    ):
        raise GitHubInputError("The GitHub repository owner or name is invalid.")
    return owner, repository


def _validate_source_path(path: str) -> str:
    if not isinstance(path, str) or not path or "\x00" in path or "\\" in path:
        raise GitHubInputError("The GitHub file path is invalid.")
    if path.startswith("/") or any(part in {"", ".", ".."} for part in path.split("/")):
        raise GitHubInputError("The GitHub file path is invalid.")
    posix_path = PurePosixPath(path)
    windows_path = PureWindowsPath(path)
    if (
        posix_path.is_absolute()
        or windows_path.is_absolute()
        or windows_path.drive
        or any(part in {"", ".", ".."} for part in posix_path.parts)
    ):
        raise GitHubInputError("The GitHub file path is invalid.")
    return posix_path.as_posix()


def _configured_token() -> str | None:
    token = os.environ.get("GITHUB_TOKEN")
    if token and token.strip():
        return token.strip()

    project_env = Path(__file__).resolve().parents[1] / ".env"
    values = dotenv_values(project_env, interpolate=False)
    configured = values.get("GITHUB_TOKEN")
    return configured.strip() if configured and configured.strip() else None


class GitHubClient:
    """Bounded GitHub REST API client; it never follows arbitrary URLs."""

    def __init__(
        self,
        token: str,
        *,
        timeout: float = REQUEST_TIMEOUT_SECONDS,
        max_response_bytes: int = MAX_RESPONSE_BYTES,
        transport: httpx.BaseTransport | None = None,
    ) -> None:
        if (
            not isinstance(token, str)
            or not token.strip()
            or any(character.isspace() for character in token)
            or token.strip().lower().startswith("your_github")
        ):
            raise GitHubInputError("Configure a valid GITHUB_TOKEN.")
        if timeout <= 0 or max_response_bytes <= 0:
            raise ValueError("GitHub request limits must be positive.")

        self._client = httpx.Client(
            base_url=GITHUB_API_URL,
            headers={
                "Accept": "application/vnd.github+json",
                "Authorization": f"Bearer {token.strip()}",
                "X-GitHub-Api-Version": "2022-11-28",
                "User-Agent": "ReviewX-AI",
            },
            timeout=httpx.Timeout(timeout),
            follow_redirects=False,
            transport=transport,
        )
        self._max_response_bytes = max_response_bytes

    def __enter__(self) -> Self:
        return self

    def __exit__(self, *_: object) -> None:
        self.close()

    def close(self) -> None:
        self._client.close()

    def _get_json(
        self,
        path: str,
        params: dict[str, str | int] | None = None,
    ) -> Any:
        try:
            with self._client.stream("GET", path, params=params) as response:
                status_code = response.status_code
                if status_code == 401:
                    raise GitHubAPIError(
                        "GitHub authentication failed.",
                        401,
                        stop_fetching=True,
                    )
                if status_code == 403:
                    if (
                        response.headers.get("X-RateLimit-Remaining") == "0"
                        or "Retry-After" in response.headers
                    ):
                        raise GitHubAPIError(
                            "GitHub API rate limit reached. Try again later.",
                            403,
                            stop_fetching=True,
                        )
                    raise GitHubAPIError(
                        "GitHub denied access to this resource.",
                        403,
                        stop_fetching=True,
                    )
                if status_code == 404:
                    raise GitHubAPIError(
                        "The GitHub resource was not found or is inaccessible.",
                        404,
                    )
                if status_code != 200:
                    raise GitHubAPIError(
                        f"GitHub returned HTTP {status_code}.",
                        status_code,
                        stop_fetching=status_code >= 500,
                    )

                content_length = response.headers.get("Content-Length")
                if content_length is not None:
                    try:
                        if int(content_length) > self._max_response_bytes:
                            raise GitHubAPIError(
                                "GitHub response exceeds the configured size limit."
                            )
                    except ValueError:
                        raise GitHubAPIError(
                            "GitHub returned invalid response-size metadata."
                        ) from None

                content = bytearray()
                for chunk in response.iter_bytes():
                    if len(content) + len(chunk) > self._max_response_bytes:
                        raise GitHubAPIError(
                            "GitHub response exceeds the configured size limit."
                        )
                    content.extend(chunk)
        except GitHubAPIError:
            raise
        except httpx.TimeoutException:
            raise GitHubAPIError(
                "The GitHub request timed out.",
                stop_fetching=True,
            ) from None
        except httpx.RequestError:
            raise GitHubAPIError(
                "Could not connect to the GitHub API.",
                stop_fetching=True,
            ) from None

        try:
            return json.loads(content)
        except (json.JSONDecodeError, UnicodeDecodeError, RecursionError):
            raise GitHubAPIError("GitHub returned an invalid JSON response.") from None

    def authenticate(self) -> str:
        user = self._get_json("/user")
        if not isinstance(user, dict) or not isinstance(user.get("login"), str):
            raise GitHubAPIError("GitHub returned invalid user information.")
        return user["login"]

    def list_repositories(self) -> list[GitHubRepository]:
        repositories: list[GitHubRepository] = []
        for page in range(1, MAX_REPOSITORY_PAGES + 1):
            payload = self._get_json(
                "/user/repos",
                {
                    "affiliation": "owner,collaborator,organization_member",
                    "per_page": PAGE_SIZE,
                    "page": page,
                    "sort": "updated",
                },
            )
            if not isinstance(payload, list):
                raise GitHubAPIError("GitHub returned an invalid repository list.")
            for item in payload:
                repositories.append(self._repository_from_payload(item))
            if len(payload) < PAGE_SIZE:
                return repositories
        raise GitHubAPIError(
            f"Repository listing exceeded the {MAX_REPOSITORY_PAGES}-page limit."
        )

    def list_pull_requests(
        self,
        owner: str,
        repository: str,
        state: str = "open",
    ) -> list[PullRequestMetadata]:
        owner, repository = validate_repository(owner, repository)
        if state not in {"open", "closed", "all"}:
            raise GitHubInputError("Pull request state must be open, closed, or all.")

        pull_requests: list[PullRequestMetadata] = []
        endpoint = f"/repos/{quote(owner, safe='')}/{quote(repository, safe='')}/pulls"
        for page in range(1, MAX_PULL_REQUEST_PAGES + 1):
            payload = self._get_json(
                endpoint,
                {"state": state, "per_page": PAGE_SIZE, "page": page},
            )
            if not isinstance(payload, list):
                raise GitHubAPIError("GitHub returned an invalid pull request list.")
            for item in payload:
                pull_requests.append(
                    self._pull_request_from_payload(item, owner, repository)
                )
            if len(payload) < PAGE_SIZE:
                return pull_requests
        raise GitHubAPIError(
            f"Pull request listing exceeded the {MAX_PULL_REQUEST_PAGES}-page limit."
        )

    def list_changed_files(
        self,
        owner: str,
        repository: str,
        pull_request_number: int,
    ) -> list[ChangedFile]:
        owner, repository = validate_repository(owner, repository)
        if type(pull_request_number) is not int or pull_request_number < 1:
            raise GitHubInputError("Pull request number must be a positive integer.")

        endpoint = (
            f"/repos/{quote(owner, safe='')}/{quote(repository, safe='')}"
            f"/pulls/{pull_request_number}/files"
        )
        files: list[ChangedFile] = []
        for page in range(1, MAX_CHANGED_FILE_PAGES + 1):
            payload = self._get_json(
                endpoint,
                {"per_page": PAGE_SIZE, "page": page},
            )
            if not isinstance(payload, list):
                raise GitHubAPIError("GitHub returned an invalid changed-file list.")
            files.extend(self._changed_file_from_payload(item) for item in payload)
            if len(payload) < PAGE_SIZE:
                return files
        raise GitHubAPIError(
            f"Changed-file listing exceeded the {MAX_CHANGED_FILE_PAGES}-page limit."
        )

    def get_file_content(
        self,
        owner: str,
        repository: str,
        path: str,
        ref: str,
    ) -> str:
        owner, repository = validate_repository(owner, repository)
        safe_path = _validate_source_path(path)
        if not isinstance(ref, str) or not re.fullmatch(r"[A-Fa-f0-9]{40}", ref):
            raise GitHubInputError("The GitHub commit reference is invalid.")

        endpoint = (
            f"/repos/{quote(owner, safe='')}/{quote(repository, safe='')}"
            f"/contents/{quote(safe_path, safe='/')}"
        )
        payload = self._get_json(endpoint, {"ref": ref})
        if not isinstance(payload, dict) or payload.get("type") != "file":
            raise GitHubAPIError("GitHub did not return a regular source file.")
        size = payload.get("size")
        if type(size) is not int or size < 0:
            raise GitHubAPIError("GitHub returned invalid source-file metadata.")
        if size > MAX_CODE_SIZE_BYTES:
            raise GitHubAPIError(
                f"The PR source file exceeds the {MAX_CODE_SIZE_BYTES}-byte limit."
            )
        encoded = payload.get("content")
        if payload.get("encoding") != "base64" or not isinstance(encoded, str):
            raise GitHubAPIError(
                "GitHub did not provide source content in a supported encoding."
            )
        try:
            content = base64.b64decode("".join(encoded.split()), validate=True)
            if len(content) != size or len(content) > MAX_CODE_SIZE_BYTES:
                raise GitHubAPIError(
                    "GitHub source content has inconsistent size metadata."
                )
            return content.decode("utf-8-sig")
        except (ValueError, UnicodeDecodeError):
            raise GitHubAPIError(
                "The PR source file is not valid UTF-8 content."
            ) from None

    def submit_review(
        self,
        owner: str,
        repository: str,
        pull_request_number: int,
        head_sha: str,
        body: str,
        comments: list[dict[str, str | int]],
        *,
        approved: bool = False,
    ) -> dict[str, Any]:
        if approved is not True:
            raise GitHubInputError(
                "Explicit user approval is required before publishing."
            )
        owner, repository = validate_repository(owner, repository)
        if type(pull_request_number) is not int or pull_request_number < 1:
            raise GitHubInputError("Pull request number must be a positive integer.")
        if not re.fullmatch(r"[A-Fa-f0-9]{40}", head_sha):
            raise GitHubInputError("The pull request head commit is invalid.")
        endpoint = (
            f"/repos/{quote(owner, safe='')}/{quote(repository, safe='')}"
            f"/pulls/{pull_request_number}/reviews"
        )
        payload = self._post_json(
            endpoint,
            {
                "commit_id": head_sha,
                "body": body,
                "event": "COMMENT",
                "comments": comments,
            },
        )
        if not isinstance(payload, dict):
            raise GitHubAPIError("GitHub returned an invalid review response.")
        return payload

    def _post_json(self, path: str, payload: dict[str, object]) -> Any:
        try:
            encoded_payload = json.dumps(
                payload,
                ensure_ascii=False,
                separators=(",", ":"),
            ).encode("utf-8")
        except (TypeError, ValueError):
            raise GitHubInputError("The GitHub review payload is invalid.") from None
        if len(encoded_payload) > MAX_REQUEST_BYTES:
            raise GitHubInputError(
                "The GitHub review exceeds the configured request-size limit."
            )

        try:
            with self._client.stream(
                "POST",
                path,
                content=encoded_payload,
                headers={"Content-Type": "application/json"},
            ) as response:
                status_code = response.status_code
                if status_code == 401:
                    raise GitHubAPIError("GitHub authentication failed.", 401)
                if status_code == 403:
                    if (
                        response.headers.get("X-RateLimit-Remaining") == "0"
                        or "Retry-After" in response.headers
                    ):
                        raise GitHubAPIError(
                            "GitHub API rate limit reached. Try again later.",
                            403,
                        )
                    raise GitHubAPIError(
                        "GitHub denied permission to publish the review.",
                        403,
                    )
                if status_code == 404:
                    raise GitHubAPIError(
                        "The GitHub resource was not found or is inaccessible.",
                        404,
                    )
                if status_code not in {200, 201}:
                    raise GitHubAPIError(
                        f"GitHub returned HTTP {status_code}.",
                        status_code,
                    )
                content_length = response.headers.get("Content-Length")
                if content_length is not None:
                    try:
                        if int(content_length) > self._max_response_bytes:
                            raise GitHubAPIError(
                                "GitHub response exceeds the configured size limit."
                            )
                    except ValueError:
                        raise GitHubAPIError(
                            "GitHub returned invalid response-size metadata."
                        ) from None
                content = bytearray()
                for chunk in response.iter_bytes():
                    if len(content) + len(chunk) > self._max_response_bytes:
                        raise GitHubAPIError(
                            "GitHub response exceeds the configured size limit."
                        )
                    content.extend(chunk)
        except GitHubAPIError:
            raise
        except httpx.TimeoutException:
            raise GitHubAPIError(
                "The GitHub request timed out.",
                stop_fetching=True,
            ) from None
        except httpx.RequestError:
            raise GitHubAPIError(
                "Could not connect to the GitHub API.",
                stop_fetching=True,
            ) from None

        try:
            result = json.loads(content)
        except (json.JSONDecodeError, UnicodeDecodeError, RecursionError):
            raise GitHubAPIError("GitHub returned an invalid JSON response.") from None
        return result

    @staticmethod
    def _repository_from_payload(payload: object) -> GitHubRepository:
        if not isinstance(payload, dict):
            raise GitHubAPIError("GitHub returned an invalid repository entry.")
        owner_data = payload.get("owner")
        full_name = payload.get("full_name")
        name = payload.get("name")
        private = payload.get("private")
        default_branch = payload.get("default_branch")
        owner = owner_data.get("login") if isinstance(owner_data, dict) else None
        if (
            not isinstance(owner, str)
            or not isinstance(name, str)
            or not isinstance(full_name, str)
            or not isinstance(private, bool)
            or not isinstance(default_branch, str)
        ):
            raise GitHubAPIError("GitHub returned incomplete repository metadata.")
        validate_repository(owner, name)
        if full_name.casefold() != f"{owner}/{name}".casefold():
            raise GitHubAPIError("GitHub returned inconsistent repository metadata.")
        return GitHubRepository(owner, name, full_name, private, default_branch)

    @staticmethod
    def _pull_request_from_payload(
        payload: object,
        owner: str,
        repository: str,
    ) -> PullRequestMetadata:
        if not isinstance(payload, dict):
            raise GitHubAPIError("GitHub returned an invalid pull request entry.")
        number = payload.get("number")
        title = payload.get("title")
        body = payload.get("body")
        user_data = payload.get("user")
        base_data = payload.get("base")
        head_data = payload.get("head")
        author = user_data.get("login") if isinstance(user_data, dict) else None
        base_branch = base_data.get("ref") if isinstance(base_data, dict) else None
        base_sha = base_data.get("sha") if isinstance(base_data, dict) else None
        head_branch = head_data.get("ref") if isinstance(head_data, dict) else None
        head_sha = head_data.get("sha") if isinstance(head_data, dict) else None
        if (
            type(number) is not int
            or number < 1
            or not isinstance(title, str)
            or not isinstance(author, str)
            or not isinstance(base_branch, str)
            or not isinstance(base_sha, str)
            or not isinstance(head_branch, str)
            or not isinstance(head_sha, str)
            or not re.fullmatch(r"[A-Fa-f0-9]{40}", base_sha)
            or not re.fullmatch(r"[A-Fa-f0-9]{40}", head_sha)
            or (body is not None and not isinstance(body, str))
        ):
            raise GitHubAPIError("GitHub returned incomplete pull request metadata.")
        return PullRequestMetadata(
            number=number,
            title=title,
            body=body or "",
            author=author,
            base_branch=base_branch,
            head_branch=head_branch,
            base_sha=base_sha,
            head_sha=head_sha,
            url=f"https://github.com/{owner}/{repository}/pull/{number}",
        )

    @staticmethod
    def _changed_file_from_payload(payload: object) -> ChangedFile:
        if not isinstance(payload, dict):
            raise GitHubAPIError("GitHub returned an invalid changed-file entry.")
        filename = payload.get("filename")
        status = payload.get("status")
        additions = payload.get("additions")
        deletions = payload.get("deletions")
        changes = payload.get("changes")
        patch = payload.get("patch")
        previous_filename = payload.get("previous_filename")
        sha = payload.get("sha")
        size = payload.get("size")
        if (
            not isinstance(filename, str)
            or not filename
            or not isinstance(status, str)
            or type(additions) is not int
            or additions < 0
            or type(deletions) is not int
            or deletions < 0
            or type(changes) is not int
            or changes < 0
            or (patch is not None and not isinstance(patch, str))
            or (previous_filename is not None and not isinstance(previous_filename, str))
            or (sha is not None and not isinstance(sha, str))
            or (size is not None and (type(size) is not int or size < 0))
        ):
            raise GitHubAPIError("GitHub returned incomplete changed-file metadata.")
        return ChangedFile(
            filename=filename,
            status=status,
            additions=additions,
            deletions=deletions,
            changes=changes,
            patch=patch,
            previous_filename=previous_filename,
            sha=sha,
            size=size,
        )


def get_github_client(
    token: str | None = None,
    *,
    transport: httpx.BaseTransport | None = None,
) -> GitHubClient:
    configured_token = token if token is not None else _configured_token()
    if configured_token is None:
        raise GitHubInputError("GITHUB_TOKEN is not configured.")
    return GitHubClient(configured_token, transport=transport)
